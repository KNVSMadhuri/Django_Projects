# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
#
# Also note: You'll have to insert the output of 'django-admin sqlcustom [app_label]'
# into your database.
from __future__ import unicode_literals

from django.db import models


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup)
    permission = models.ForeignKey('AuthPermission')

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group_id', 'permission_id'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    content_type = models.ForeignKey('DjangoContentType')
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type_id', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=254, blank=True, null=True)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser)
    group = models.ForeignKey(AuthGroup)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user_id', 'group_id'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser)
    permission = models.ForeignKey(AuthPermission)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user_id', 'permission_id'),)


class CadenceCannibalization(models.Model):
    stylclrcd = models.CharField(db_column='StylClrCd', primary_key=True, max_length=10)  # Field name made lowercase.
    sub_category = models.CharField(db_column='Sub_Category', max_length=23, blank=True, null=True)  # Field name made lowercase.
    takes1 = models.CharField(db_column='Takes1', max_length=12, blank=True, null=True)  # Field name made lowercase.
    takes2 = models.CharField(db_column='Takes2', max_length=21, blank=True, null=True)  # Field name made lowercase.
    gives1 = models.CharField(db_column='Gives1', max_length=12, blank=True, null=True)  # Field name made lowercase.
    gives2 = models.CharField(db_column='Gives2', max_length=21, blank=True, null=True)  # Field name made lowercase.
    time_stamp = models.CharField(max_length=10, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cadence_cannibalization'


class CadencePlanning(models.Model):
    cadence_planning_name = models.CharField(max_length=150)
    combination_key = models.CharField(max_length=50)
    brand_name = models.CharField(db_column='Brand_name', max_length=60)  # Field name made lowercase.
    season = models.CharField(max_length=50)
    season_key = models.CharField(db_column='season_Key', max_length=30)  # Field name made lowercase.
    year_key = models.IntegerField(db_column='Year_Key')  # Field name made lowercase.
    created = models.DateField()
    modified = models.DateField()
    user = models.ForeignKey(AuthUser)

    class Meta:
        managed = False
        db_table = 'cadence_planning'


class CadencePlanningproducts(models.Model):
    style_name = models.CharField(db_column='Style_name', max_length=200)  # Field name made lowercase.
    abbreviated_name = models.CharField(db_column='Abbreviated_name', max_length=60)  # Field name made lowercase.
    stylclrcd = models.CharField(db_column='StylClrCd', max_length=100)  # Field name made lowercase.
    shoe_class = models.CharField(db_column='Shoe_Class', max_length=20)  # Field name made lowercase.
    launch_date = models.DateField(db_column='Launch_Date')  # Field name made lowercase.
    day1_str = models.FloatField(db_column='Day1_STR')  # Field name made lowercase.
    day1_sales = models.FloatField(db_column='Day1_Sales')  # Field name made lowercase.
    week1_str = models.FloatField(db_column='Week1_STR')  # Field name made lowercase.
    week1_sales = models.FloatField(db_column='Week1_Sales')  # Field name made lowercase.
    total_inventory = models.BigIntegerField(db_column='Total_Inventory')  # Field name made lowercase.
    msrp = models.IntegerField(db_column='MSRP')  # Field name made lowercase.
    image_url = models.CharField(max_length=500)
    planned_launch_date = models.DateField()
    planned_inv = models.IntegerField()
    top_opportunity_flag = models.IntegerField(db_column='Top_opportunity_flag')  # Field name made lowercase.
    canninalization = models.TextField()
    is_planned = models.IntegerField()
    created = models.DateField()
    modified = models.DateField()
    cadence_planning = models.ForeignKey(CadencePlanning)

    class Meta:
        managed = False
        db_table = 'cadence_planningproducts'


class CadenceQuarter(models.Model):
    quarter_name = models.CharField(max_length=60)
    year = models.IntegerField()
    start_date = models.DateField()
    end_date = models.DateField()

    class Meta:
        managed = False
        db_table = 'cadence_quarter'


class CadenceTeradata(models.Model):
    id = models.IntegerField(primary_key=True)
    combination_key = models.CharField(max_length=4, blank=True, null=True)
    top_opportunity_flag = models.IntegerField(db_column='Top_opportunity_flag', blank=True, null=True)  # Field name made lowercase.
    brand_name = models.CharField(db_column='Brand_name', max_length=7, blank=True, null=True)  # Field name made lowercase.
    style_name = models.CharField(db_column='Style_name', max_length=7, blank=True, null=True)  # Field name made lowercase.
    abbreviated_name = models.CharField(db_column='Abbreviated_name', max_length=10, blank=True, null=True)  # Field name made lowercase.
    stylclrcd = models.CharField(db_column='StylClrCd', max_length=10, blank=True, null=True)  # Field name made lowercase.
    shoe_class = models.CharField(db_column='Shoe_Class', max_length=8, blank=True, null=True)  # Field name made lowercase.
    launch_date = models.CharField(db_column='Launch_Date', max_length=10, blank=True, null=True)  # Field name made lowercase.
    season = models.CharField(db_column='Season', max_length=4, blank=True, null=True)  # Field name made lowercase.
    seaon_key = models.CharField(db_column='Seaon key', max_length=2, blank=True, null=True)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    year_key = models.IntegerField(db_column='Year key', blank=True, null=True)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    day1_str = models.DecimalField(db_column='Day1_STR', max_digits=10, decimal_places=9, blank=True, null=True)  # Field name made lowercase.
    day1_sales = models.DecimalField(db_column='Day1_Sales', max_digits=25, decimal_places=9, blank=True, null=True)  # Field name made lowercase.
    week1_str = models.DecimalField(db_column='Week1_STR', max_digits=10, decimal_places=9, blank=True, null=True)  # Field name made lowercase.
    week1_sales = models.DecimalField(db_column='Week1_Sales', max_digits=25, decimal_places=9, blank=True, null=True)  # Field name made lowercase.
    total_inventory = models.IntegerField(db_column='Total_Inventory', blank=True, null=True)  # Field name made lowercase.
    msrp = models.IntegerField(db_column='MSRP', blank=True, null=True)  # Field name made lowercase.
    prcnt_avg_mrkp = models.DecimalField(db_column='PRCNT_AVG_MRKP', max_digits=3, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    overall_launches = models.IntegerField(db_column='Overall_launches', blank=True, null=True)  # Field name made lowercase.
    category_launches = models.IntegerField(db_column='Category_launches', blank=True, null=True)  # Field name made lowercase.
    test_revenue = models.DecimalField(max_digits=24, decimal_places=8, blank=True, null=True)
    overall_revenue = models.DecimalField(db_column='Overall_revenue', max_digits=21, decimal_places=5, blank=True, null=True)  # Field name made lowercase.
    overall_tier_revenue = models.DecimalField(db_column='Overall_tier_revenue', max_digits=22, decimal_places=6, blank=True, null=True)  # Field name made lowercase.
    category_revenue = models.DecimalField(db_column='Category_revenue', max_digits=22, decimal_places=6, blank=True, null=True)  # Field name made lowercase.
    category_tier_revenue = models.DecimalField(db_column='Category_tier_revenue', max_digits=24, decimal_places=8, blank=True, null=True)  # Field name made lowercase.
    overall_inv = models.IntegerField(db_column='Overall_Inv', blank=True, null=True)  # Field name made lowercase.
    overall_tier_inv = models.IntegerField(db_column='Overall_tier_Inv', blank=True, null=True)  # Field name made lowercase.
    category_inv = models.IntegerField(db_column='Category_Inv', blank=True, null=True)  # Field name made lowercase.
    category_tier_inv = models.IntegerField(db_column='Category_tier_Inv', blank=True, null=True)  # Field name made lowercase.
    overall_tier_day_str = models.DecimalField(db_column='Overall_tier_day_STR', max_digits=11, decimal_places=10, blank=True, null=True)  # Field name made lowercase.
    category_tier_day_str = models.DecimalField(db_column='Category_tier_day_STR', max_digits=11, decimal_places=10, blank=True, null=True)  # Field name made lowercase.
    overall_tier_wk_str = models.DecimalField(db_column='Overall_tier_wk_STR', max_digits=11, decimal_places=10, blank=True, null=True)  # Field name made lowercase.
    category_tier_wk_str = models.DecimalField(db_column='Category_tier_wk_STR', max_digits=11, decimal_places=10, blank=True, null=True)  # Field name made lowercase.
    week_inv = models.IntegerField(db_column='Week_Inv', blank=True, null=True)  # Field name made lowercase.
    week_revenue = models.DecimalField(db_column='Week_revenue', max_digits=24, decimal_places=8, blank=True, null=True)  # Field name made lowercase.
    planned_launch_date = models.CharField(max_length=10, blank=True, null=True)
    planned_inv = models.IntegerField(blank=True, null=True)
    image_url = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'cadence_teradata'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', blank=True, null=True)
    user = models.ForeignKey(AuthUser)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class Oauth2ProviderAccesstoken(models.Model):
    token = models.CharField(max_length=255)
    expires = models.DateTimeField()
    scope = models.TextField()
    application = models.ForeignKey('Oauth2ProviderApplication')
    user = models.ForeignKey(AuthUser, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'oauth2_provider_accesstoken'


class Oauth2ProviderApplication(models.Model):
    client_id = models.CharField(unique=True, max_length=100)
    redirect_uris = models.TextField()
    client_type = models.CharField(max_length=32)
    authorization_grant_type = models.CharField(max_length=32)
    client_secret = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    user = models.ForeignKey(AuthUser)
    skip_authorization = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'oauth2_provider_application'


class Oauth2ProviderGrant(models.Model):
    code = models.CharField(max_length=255)
    expires = models.DateTimeField()
    redirect_uri = models.CharField(max_length=255)
    scope = models.TextField()
    application = models.ForeignKey(Oauth2ProviderApplication)
    user = models.ForeignKey(AuthUser)

    class Meta:
        managed = False
        db_table = 'oauth2_provider_grant'


class Oauth2ProviderRefreshtoken(models.Model):
    token = models.CharField(max_length=255)
    access_token = models.ForeignKey(Oauth2ProviderAccesstoken, unique=True)
    application = models.ForeignKey(Oauth2ProviderApplication)
    user = models.ForeignKey(AuthUser)

    class Meta:
        managed = False
        db_table = 'oauth2_provider_refreshtoken'
