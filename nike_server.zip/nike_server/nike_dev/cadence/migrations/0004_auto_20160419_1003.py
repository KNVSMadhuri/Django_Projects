# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0003_quarter'),
    ]

    operations = [
        migrations.AlterField(
            model_name='planning',
            name='modified',
            field=models.DateField(auto_now=True),
        ),
        migrations.AlterField(
            model_name='planningproducts',
            name='modified',
            field=models.DateField(auto_now=True),
        ),
    ]
