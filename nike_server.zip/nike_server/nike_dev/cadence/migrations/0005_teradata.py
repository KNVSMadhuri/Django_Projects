# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0004_auto_20160419_1003'),
    ]

    operations = [
        migrations.CreateModel(
            name='Teradata',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('combination_key', models.CharField(max_length=4)),
                ('Top_opportunity_flag', models.IntegerField()),
                ('Brand_name', models.CharField(max_length=7)),
                ('Style_name', models.CharField(max_length=7)),
                ('Abbreviated_name', models.CharField(max_length=10)),
                ('StylClrCd', models.CharField(max_length=10)),
                ('Shoe_Class', models.CharField(max_length=8)),
                ('Launch_Date', models.CharField(max_length=10)),
                ('Season', models.CharField(max_length=4)),
                ('Seaon_key', models.CharField(max_length=2)),
                ('Year_key', models.IntegerField()),
                ('Day1_STR', models.DecimalField(max_digits=10, decimal_places=9)),
                ('Day1_Sales', models.DecimalField(max_digits=25, decimal_places=9)),
                ('Week1_STR', models.DecimalField(max_digits=15, decimal_places=9)),
                ('Week1_Sales', models.DecimalField(max_digits=25, decimal_places=9)),
                ('Total_Inventory', models.IntegerField()),
                ('MSRP', models.IntegerField()),
                ('PRCNT_AVG_MRKP', models.DecimalField(max_digits=3, decimal_places=2)),
                ('Overall_launches', models.IntegerField()),
                ('Category_launches', models.IntegerField()),
                ('test_revenue', models.DecimalField(max_digits=24, decimal_places=8)),
                ('Overall_revenue', models.DecimalField(max_digits=21, decimal_places=5)),
                ('Overall_tier_revenue', models.DecimalField(max_digits=22, decimal_places=6)),
                ('Category_revenue', models.DecimalField(max_digits=22, decimal_places=6)),
                ('Category_tier_revenue', models.DecimalField(max_digits=24, decimal_places=8)),
                ('Overall_Inv', models.IntegerField()),
                ('Overall_tier_Inv', models.IntegerField()),
                ('Category_Inv', models.IntegerField()),
                ('Category_tier_Inv', models.IntegerField()),
                ('Overall_tier_day_STR', models.DecimalField(max_digits=11, decimal_places=10)),
                ('Category_tier_day_STR', models.DecimalField(max_digits=11, decimal_places=10)),
                ('Overall_tier_wk_STR', models.DecimalField(max_digits=11, decimal_places=10)),
                ('Category_tier_wk_STR', models.DecimalField(max_digits=11, decimal_places=10)),
                ('Week_Inv', models.IntegerField()),
                ('Week_revenue', models.DecimalField(max_digits=24, decimal_places=8)),
                ('planned_launch_date', models.CharField(max_length=10)),
                ('planned_inv', models.IntegerField()),
                ('image_url', models.CharField(max_length=200)),
            ],
        ),
    ]
