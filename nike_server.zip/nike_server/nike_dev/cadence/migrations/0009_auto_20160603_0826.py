# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0008_auto_20160517_0716'),
    ]

    operations = [
        migrations.CreateModel(
            name='PlanningFolder',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('folder_name', models.CharField(max_length=100)),
                ('access', models.BooleanField(default=False, unique=True)),
                ('created', models.DateField(auto_now_add=True)),
            ],
        ),
        migrations.AlterUniqueTogether(
            name='planning',
            unique_together=set([('cadence_planning_name', 'planning_folder')]),
        ),
        migrations.AddField(
            model_name='planning',
            name='planning_folder',
            field=models.ForeignKey(default=1, to='cadence.PlanningFolder', max_length=10),
            preserve_default=False,
        ),
    ]
