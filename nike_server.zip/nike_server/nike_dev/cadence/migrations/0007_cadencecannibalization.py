# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0006_auto_20160420_1251'),
    ]

    operations = [
        migrations.CreateModel(
            name='CadenceCannibalization',
            fields=[
                ('stylclrcd', models.CharField(max_length=10, serialize=False, primary_key=True, db_column=b'StylClrCd')),
                ('sub_category', models.CharField(max_length=23, null=True, db_column=b'Sub_Category', blank=True)),
                ('takes1', models.CharField(max_length=12, null=True, db_column=b'Takes1', blank=True)),
                ('takes2', models.CharField(max_length=21, null=True, db_column=b'Takes2', blank=True)),
                ('gives1', models.CharField(max_length=12, null=True, db_column=b'Gives1', blank=True)),
                ('gives2', models.CharField(max_length=21, null=True, db_column=b'Gives2', blank=True)),
                ('time_stamp', models.CharField(max_length=10, null=True, blank=True)),
            ],
            options={
                'db_table': 'cadence_cannibalization',
                'managed': False,
            },
        ),
    ]
