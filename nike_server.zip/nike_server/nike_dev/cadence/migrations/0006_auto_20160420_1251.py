# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0005_teradata'),
    ]

    operations = [
        migrations.CreateModel(
            name='CadenceTeradata',
            fields=[
                ('id', models.IntegerField(serialize=False, primary_key=True)),
                ('combination_key', models.CharField(max_length=4, null=True, blank=True)),
                ('top_opportunity_flag', models.IntegerField(null=True, db_column=b'Top_opportunity_flag', blank=True)),
                ('brand_name', models.CharField(max_length=7, null=True, db_column=b'Brand_name', blank=True)),
                ('style_name', models.CharField(max_length=7, null=True, db_column=b'Style_name', blank=True)),
                ('abbreviated_name', models.CharField(max_length=10, null=True, db_column=b'Abbreviated_name', blank=True)),
                ('stylclrcd', models.CharField(max_length=10, null=True, db_column=b'StylClrCd', blank=True)),
                ('shoe_class', models.CharField(max_length=8, null=True, db_column=b'Shoe_Class', blank=True)),
                ('launch_date', models.CharField(max_length=10, null=True, db_column=b'Launch_Date', blank=True)),
                ('season', models.CharField(max_length=4, null=True, db_column=b'Season', blank=True)),
                ('seaon_key', models.CharField(max_length=2, null=True, db_column=b'Seaon key', blank=True)),
                ('year_key', models.IntegerField(null=True, db_column=b'Year key', blank=True)),
                ('day1_str', models.DecimalField(null=True, decimal_places=9, max_digits=10, db_column=b'Day1_STR', blank=True)),
                ('day1_sales', models.DecimalField(null=True, decimal_places=9, max_digits=25, db_column=b'Day1_Sales', blank=True)),
                ('week1_str', models.DecimalField(null=True, decimal_places=9, max_digits=10, db_column=b'Week1_STR', blank=True)),
                ('week1_sales', models.DecimalField(null=True, decimal_places=9, max_digits=25, db_column=b'Week1_Sales', blank=True)),
                ('total_inventory', models.IntegerField(null=True, db_column=b'Total_Inventory', blank=True)),
                ('msrp', models.IntegerField(null=True, db_column=b'MSRP', blank=True)),
                ('prcnt_avg_mrkp', models.DecimalField(null=True, decimal_places=2, max_digits=3, db_column=b'PRCNT_AVG_MRKP', blank=True)),
                ('overall_launches', models.IntegerField(null=True, db_column=b'Overall_launches', blank=True)),
                ('category_launches', models.IntegerField(null=True, db_column=b'Category_launches', blank=True)),
                ('test_revenue', models.DecimalField(null=True, max_digits=24, decimal_places=8, blank=True)),
                ('overall_revenue', models.DecimalField(null=True, decimal_places=5, max_digits=21, db_column=b'Overall_revenue', blank=True)),
                ('overall_tier_revenue', models.DecimalField(null=True, decimal_places=6, max_digits=22, db_column=b'Overall_tier_revenue', blank=True)),
                ('category_revenue', models.DecimalField(null=True, decimal_places=6, max_digits=22, db_column=b'Category_revenue', blank=True)),
                ('category_tier_revenue', models.DecimalField(null=True, decimal_places=8, max_digits=24, db_column=b'Category_tier_revenue', blank=True)),
                ('overall_inv', models.IntegerField(null=True, db_column=b'Overall_Inv', blank=True)),
                ('overall_tier_inv', models.IntegerField(null=True, db_column=b'Overall_tier_Inv', blank=True)),
                ('category_inv', models.IntegerField(null=True, db_column=b'Category_Inv', blank=True)),
                ('category_tier_inv', models.IntegerField(null=True, db_column=b'Category_tier_Inv', blank=True)),
                ('overall_tier_day_str', models.DecimalField(null=True, decimal_places=10, max_digits=11, db_column=b'Overall_tier_day_STR', blank=True)),
                ('category_tier_day_str', models.DecimalField(null=True, decimal_places=10, max_digits=11, db_column=b'Category_tier_day_STR', blank=True)),
                ('overall_tier_wk_str', models.DecimalField(null=True, decimal_places=10, max_digits=11, db_column=b'Overall_tier_wk_STR', blank=True)),
                ('category_tier_wk_str', models.DecimalField(null=True, decimal_places=10, max_digits=11, db_column=b'Category_tier_wk_STR', blank=True)),
                ('week_inv', models.IntegerField(null=True, db_column=b'Week_Inv', blank=True)),
                ('week_revenue', models.DecimalField(null=True, decimal_places=8, max_digits=24, db_column=b'Week_revenue', blank=True)),
                ('planned_launch_date', models.CharField(max_length=10, null=True, blank=True)),
                ('planned_inv', models.IntegerField(null=True, blank=True)),
                ('image_url', models.CharField(max_length=200)),
            ],
            options={
                'db_table': 'cadence_teradata',
                'managed': False,
            },
        ),
        migrations.DeleteModel(
            name='Teradata',
        ),
    ]
