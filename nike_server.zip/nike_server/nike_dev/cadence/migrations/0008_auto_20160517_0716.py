# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0007_cadencecannibalization'),
    ]

    operations = [
        migrations.RenameField(
            model_name='quarter',
            old_name='year',
            new_name='year_key',
        ),
        migrations.RemoveField(
            model_name='quarter',
            name='quarter_name',
        ),
        migrations.AddField(
            model_name='quarter',
            name='season',
            field=models.CharField(default=1, max_length=6),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='quarter',
            name='season_key',
            field=models.CharField(default=1, max_length=3),
            preserve_default=False,
        ),
    ]
