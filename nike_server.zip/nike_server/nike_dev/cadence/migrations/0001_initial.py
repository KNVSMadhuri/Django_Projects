# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Planning',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('cadence_planning_name', models.CharField(max_length=150)),
                ('combination_key', models.CharField(max_length=50)),
                ('Brand_name', models.CharField(max_length=60)),
                ('season', models.CharField(max_length=50)),
                ('season_Key', models.CharField(max_length=30)),
                ('Year_Key', models.IntegerField(default=0)),
                ('created', models.DateField(auto_now_add=True)),
                ('modified', models.DateField()),
                ('user', models.ForeignKey(related_name='user_from_of_an_forum', to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]
