# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cadence', '0002_auto_20160419_0821'),
    ]

    operations = [
        migrations.CreateModel(
            name='quarter',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('quarter_name', models.CharField(max_length=60)),
                ('year', models.IntegerField(default=0)),
                ('start_date', models.DateField(default=False)),
                ('end_date', models.DateField(default=False)),
            ],
        ),
    ]
