from rest_framework import serializers
from django.contrib.auth.models import User,Group
from django.db.models import Max
from models import *
from django.db.models import Count

class QuarterSerializer(serializers.ModelSerializer):
	
	class Meta:
		model = quarter
		

class ScenarioSerializer(serializers.ModelSerializer):
	
	class Meta:
		model = Planning

class CanibalizationSerializer(serializers.ModelSerializer):
	
	class Meta:
		model = CadenceCannibalization


class PlanningFolderSerializer(serializers.ModelSerializer):
	related_plannings=serializers.SerializerMethodField()

	class Meta:
		model = PlanningFolder
		fields = ('id','folder_name','access','created','related_plannings')

	def get_related_plannings(self,obj):
		instance = Planning.objects.filter(planning_folder=obj.id).values()
		return instance

class PlanningFolderDefaultSerializer(serializers.ModelSerializer):
	#related_plannings=serializers.SerializerMethodField()

	class Meta:
		model = PlanningFolder
		#fields = ('id','folder_name','access','created','related_plannings')
	

		
# class TeradataSerializer(serializers.ModelSerializer):

# 	stylclrcd=serializers.SerializerMethodField()
# 	class Meta:
# 		model = CadenceTeradata

# 	def get_stylclrcd(self,obj):
# 		import pdb
# 		#pdb.set_trace()
# 		instance = CadenceCannibalization.objects.filter(stylclrcd=obj.stylclrcd_id).order_by('-time_stamp').first()
# 		if instance is not None:
# 			return  CanibalizationSerializer(instance=instance).data
# 		else:
# 			return {}


		

class SignUpSerializer(serializers.ModelSerializer):
	class Meta:
		model = User
		fields = ('username', 'password')
		write_only_fields = ('password',)

class TeradataSerializer(serializers.ModelSerializer):
	class Meta:
		model = CadenceTeradata
		fields = ('id','year_key','combination_key','top_opportunity_flag','brand_name','style_name','style_abbr','stylclrcd','shoe_class','launch_date','abbreviated_name','season','season_key','year_key','day1_str','day1_sales','week1_str','week1_sales','total_inventory','msrp','prcnt_avg_mrkp','overall_launches','category_launches','overall_revenue','overall_tier_revenue','category_revenue','category_tier_revenue','overall_inv','overall_tier_inv','category_inv','category_tier_inv','overall_tier_day_str','category_tier_day_str','overall_tier_wk_str','category_tier_wk_str','week_inv','week_revenue','planned_launch_date','planned_inv')


class TeradataSerializer1(serializers.ModelSerializer):
	"""
	"""
	last=serializers.SerializerMethodField()
	stylclrcd=serializers.SerializerMethodField()
	defaultvalue=serializers.SerializerMethodField()
	class Meta:
		model = CadenceTeradata
		fields = ('id','last','defaultvalue','year_key','combination_key','top_opportunity_flag','brand_name','style_name','style_abbr','stylclrcd','shoe_class','launch_date','abbreviated_name','season','season_key','year_key','day1_str','day1_sales','week1_str','week1_sales','total_inventory','msrp','prcnt_avg_mrkp','overall_launches','category_launches','overall_revenue','overall_tier_revenue','category_revenue','category_tier_revenue','overall_inv','overall_tier_inv','category_inv','category_tier_inv','overall_tier_day_str','category_tier_day_str','overall_tier_wk_str','category_tier_wk_str','week_inv','week_revenue','planned_launch_date','planned_inv')

	# def get_last(self,obj):
	# 	last_year = CadenceTeradata.objects.filter(year_key__lt=obj.year_key,season_key = obj.season_key)
	# 	last_year_key = last_year.aggregate(Max('year_key'))
	# 	last_year_data = CadenceTeradata.objects.filter(year_key=last_year_key['year_key__max'],season_key=obj.season_key,combination_key=obj.combination_key)
		
	# 	return TeradataSerializer11(last_year_data,many=True).data

	def get_last(self,obj):
		last_year = CadenceTeradata.objects.filter(year_key__lt=obj.year_key,season_key = obj.season_key)
		last_year_key = last_year.aggregate(Max('year_key'))
		last_year_data = CadenceTeradata.objects.filter(year_key=last_year_key['year_key__max'],season_key=obj.season_key).values()
		#last_year_data1 = CadenceTeradata.objects.raw('SELECT * FROM cadence_teradata where year_key = "'+ last_year_key['year_key__max'] +'" and Season_key = "'+obj.season_key +'" group by shoe_class, brand_name')
		#last_year_data = TeradataSerializer(last_year_data1,many=True).data
		return last_year_data

	def get_stylclrcd(self,obj):
		instance = CadenceCannibalization.objects.filter(stylclrcd=obj.stylclrcd_id).order_by('-time_stamp').values()
		if len(instance) > 0:
			return  instance[0]
		else:
			return {}

	def get_defaultvalue(self,obj):
		#if int(obj.top_opportunity_flag) > 0:
		combination_len = len(obj.combination_key)
		default_combination = '%0*d' % (combination_len, 0)
		default_value = CadenceTeradata.objects.filter(combination_key=default_combination,stylclrcd=obj.stylclrcd_id).values()
		if default_value.count() > 0:
			return default_value[0]
		else:
			return {}


		
