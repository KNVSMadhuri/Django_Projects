from django.conf.urls import patterns, include, url
from rest_framework import routers
from views import CadendenPlanningDelete,CadendenFolderDelete,CadendenFolderCreate,HelloPDFView,QuarterList,ScenarioList,ScenarioListDetail,TeradataList,CadenceSave,CadendenFolderListDetail

urlpatterns = [
			
			url(r'^quarter/$', QuarterList.as_view()),
			#url(r'^$', ScenarioList.as_view()),	
			url(r'^$', CadendenFolderListDetail.as_view()),
			url(r'^senarioSave/$', ScenarioList.as_view()),	
			url(r'^senarioUpdate/$', ScenarioListDetail.as_view()),
			url(r'^(?P<pk>[0-9]+)/$', ScenarioListDetail.as_view()),
			url(r'^teradata/$', TeradataList.as_view()),
			url(r'^createFolder/$', CadendenFolderCreate.as_view()),
			url(r'^deleteFolder/(?P<pk>[0-9]+)/$', CadendenFolderDelete.as_view()),
			url(r'^deleteCadencePlanning/(?P<pk>[0-9]+)/$', CadendenPlanningDelete.as_view()),
			url(r'^date/$', CadenceSave),
			url(r"^hellopdf/$", HelloPDFView.as_view())				
]