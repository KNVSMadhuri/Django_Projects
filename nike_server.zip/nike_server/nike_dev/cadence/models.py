from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import NON_FIELD_ERRORS

# Create your models here.
"""
	Here,The Following Models Are Available
	Models Are :
				Planning
				PlanningProducts
				quarter
"""
class PlanningFolder(models.Model):
	"""docstring for PlanningFolder"""
	
	folder_name = models.CharField(max_length=100,unique=True)
	access=models.BooleanField(default=False)
	created =models.DateField(auto_now_add=True)
	
		
class Planning(models.Model):
	''' 
		Cadence planning done by user with there create date.
	
	'''
	
	user = models.ForeignKey(User,related_name='user_created_cadence')
	cadence_planning_name =models.CharField(max_length=150)
	combination_key = models.CharField(max_length=50)
	Brand_name = models.CharField(max_length=60)
	season = models.CharField(max_length=50)
	season_Key = models.CharField(max_length=30)
	Year_Key = models.IntegerField(default=0)
	created = models.DateField(auto_now_add=True)
	planning_folder = models.ForeignKey('PlanningFolder', max_length=10,on_delete=models.CASCADE)
	modified = models.DateField(auto_now=True)

	class Meta:
		unique_together = ('cadence_planning_name', 'planning_folder',)
		# error_messages = {
		# 	NON_FIELD_ERRORS: {
		# 		'unique_together': "File Name has to be unique.",
		# 	}
		# }

class PlanningProducts(models.Model):
	'''
		Product details with respect to cadence planning

	'''

	cadence_planning = models.ForeignKey(Planning, related_name='cadence_planning')
	Style_name = models.CharField(max_length=200)
	Abbreviated_name = models.CharField(max_length=60)
	StylClrCd = models.CharField(max_length=100)
	Shoe_Class = models.CharField(max_length=20)
	Launch_Date = models.DateField(auto_now_add=False)
	Day1_STR = models.FloatField(default=0)
	Day1_Sales = models.FloatField(default=0)
	Week1_STR = models.FloatField(default=0)
	Week1_Sales = models.FloatField(default=0)
	Total_Inventory = models.BigIntegerField()
	MSRP = models.IntegerField(default=0)
	image_url = models.CharField(max_length=500)
	planned_launch_date = models.DateField(auto_now_add=False)
	planned_inv = models.IntegerField(default=0)
	Top_opportunity_flag = models.IntegerField(default=0)
	canninalization = models.TextField()
	is_planned = models.BooleanField(default=False)
	created =models.DateField(auto_now_add=True)
	modified = models.DateField(auto_now=True)

class quarter(models.Model):
	season = models.CharField(max_length=6)
	year_key = models.IntegerField(default=00)
	season_key = models.CharField(max_length=3)
	start_date = models.DateField(default = False)
	end_date = models.DateField(default = False)

class CadenceCannibalization(models.Model):
	stylclrcd = models.CharField(db_column='StylClrCd', primary_key=True, max_length=10)  # Field name made lowercase.
	sub_category = models.CharField(db_column='Sub_Category', max_length=23, blank=True, null=True)  # Field name made lowercase.
	takes1 = models.CharField(db_column='Takes1', max_length=12, blank=True, null=True)  # Field name made lowercase.
	takes2 = models.CharField(db_column='Takes2', max_length=21, blank=True, null=True)  # Field name made lowercase.
	gives1 = models.CharField(db_column='Gives1', max_length=12, blank=True, null=True)  # Field name made lowercase.
	gives2 = models.CharField(db_column='Gives2', max_length=21, blank=True, null=True)  # Field name made lowercase.
	time_stamp = models.CharField(max_length=10, blank=True, null=True)

	class Meta:
		managed = False
		db_table = 'cadence_cannibalization'


class CadenceTeradata(models.Model):
	id = models.IntegerField(primary_key=True)
	combination_key = models.CharField(max_length=15, blank=True, null=True)
	top_opportunity_flag = models.CharField(db_column='Top_opportunity_flag', max_length=20, blank=True, null=True)  # Field name made lowercase.
	brand_name = models.CharField(db_column='Brand_name', max_length=10, blank=True, null=True)  # Field name made lowercase.
	style_name = models.CharField(db_column='Style_name', max_length=50, blank=True, null=True)  # Field name made lowercase.
	#stylclrcd = models.CharField(db_column='StylClrCd', max_length=10, blank=True, null=True)  # Field name made lowercase.
	stylclrcd = models.ForeignKey('CadenceCannibalization',db_column='StylClrCd', max_length=10, blank=True, null=True)  # Field name made lowercase.
	shoe_class = models.CharField(db_column='Shoe_Class', max_length=10, blank=True, null=True)  # Field name made lowercase.
	launch_date = models.CharField(db_column='Launch_Date', max_length=11, blank=True, null=True)  # Field name made lowercase.
	season = models.CharField(db_column='Season', max_length=6, blank=True, null=True)  # Field name made lowercase.
	day1_str = models.CharField(db_column='Day1_STR', max_length=8, blank=True, null=True)  # Field name made lowercase.
	day1_sales = models.CharField(db_column='Day1_Sales', max_length=11, blank=True, null=True)  # Field name made lowercase.
	week1_str = models.CharField(db_column='Week1_STR', max_length=9, blank=True, null=True)  # Field name made lowercase.
	week1_sales = models.CharField(db_column='Week1_Sales', max_length=11, blank=True, null=True)  # Field name made lowercase.
	total_inventory = models.CharField(db_column='Total_Inventory', max_length=15, blank=True, null=True)  # Field name made lowercase.
	msrp = models.CharField(db_column='MSRP', max_length=4, blank=True, null=True)  # Field name made lowercase.
	prcnt_avg_mrkp = models.CharField(db_column='PRCNT_AVG_MRKP', max_length=14, blank=True, null=True)  # Field name made lowercase.
	overall_launches = models.CharField(db_column='Overall_launches', max_length=16, blank=True, null=True)  # Field name made lowercase.
	category_launches = models.CharField(db_column='Category_launches', max_length=17, blank=True, null=True)  # Field name made lowercase.
	overall_revenue = models.CharField(db_column='Overall_revenue', max_length=15, blank=True, null=True)  # Field name made lowercase.
	overall_tier_revenue = models.CharField(db_column='Overall_tier_revenue', max_length=20, blank=True, null=True)  # Field name made lowercase.
	category_revenue = models.CharField(db_column='Category_revenue', max_length=16, blank=True, null=True)  # Field name made lowercase.
	category_tier_revenue = models.CharField(db_column='Category_tier_revenue', max_length=21, blank=True, null=True)  # Field name made lowercase.
	overall_inv = models.CharField(db_column='Overall_Inv', max_length=11, blank=True, null=True)  # Field name made lowercase.
	overall_tier_inv = models.CharField(db_column='Overall_tier_Inv', max_length=16, blank=True, null=True)  # Field name made lowercase.
	category_inv = models.CharField(db_column='Category_Inv', max_length=12, blank=True, null=True)  # Field name made lowercase.
	category_tier_inv = models.CharField(db_column='Category_tier_Inv', max_length=17, blank=True, null=True)  # Field name made lowercase.
	overall_tier_day_str = models.CharField(db_column='Overall_tier_day_STR', max_length=20, blank=True, null=True)  # Field name made lowercase.
	category_tier_day_str = models.CharField(db_column='Category_tier_day_STR', max_length=21, blank=True, null=True)  # Field name made lowercase.
	overall_tier_wk_str = models.CharField(db_column='Overall_tier_wk_STR', max_length=19, blank=True, null=True)  # Field name made lowercase.
	category_tier_wk_str = models.CharField(db_column='Category_tier_wk_STR', max_length=20, blank=True, null=True)  # Field name made lowercase.
	week_inv = models.CharField(db_column='Week_Inv', max_length=8, blank=True, null=True)  # Field name made lowercase.
	week_revenue = models.CharField(db_column='Week_revenue', max_length=14, blank=True, null=True)  # Field name made lowercase.
	planned_launch_date = models.CharField(max_length=19, blank=True, null=True)
	planned_inv = models.CharField(max_length=11, blank=True, null=True)
	season_key = models.CharField(db_column='Season_key', max_length=10, blank=True, null=True)  # Field name made lowercase.
	year_key = models.CharField(db_column='Year_key', max_length=8, blank=True, null=True)  # Field name made lowercase.
	style_abbr = models.CharField(max_length=10, blank=True, null=True)
	abbreviated_name = models.CharField(db_column='Abbreviated_name', max_length=60)  # Field name made lowercase.

	class Meta:
		managed = False
		db_table = 'cadence_teradata'

