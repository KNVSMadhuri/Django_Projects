from rest_framework import permissions
from django.shortcuts import render, render_to_response
from django.http import HttpResponseRedirect,HttpResponse
import pdb

class IsAuthenticated(permissions.BasePermission):
	def has_permission(self, request, view):
		if 'samlUserdata' in request.session:
			if len(request.session['samlUserdata']) > 0:
				if 'Groups' in request.session['samlUserdata']:
					if 'Application.LaunchTool.Dev.NAA.PowerUser' in request.session['samlUserdata']['Groups'] or 'Application.LaunchTool.Dev.NAA.Administrator' in request.session['samlUserdata']['Groups'] or  'Application.LaunchTool.Dev.NAA.Viewer' in request.session['samlUserdata']['Groups']:
						return True
					else:
						return False
				else:
					return False
			else:
				return False
		else:
			return False
		