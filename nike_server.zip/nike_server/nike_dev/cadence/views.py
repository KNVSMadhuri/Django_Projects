
from django.shortcuts import render
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from permissions import *
from oauth2_provider.models import Application
from oauth2_provider.ext.rest_framework import TokenHasReadWriteScope, TokenHasScope
from django.db.models import Count
from models import *
from serializers import *
from django.db.models import Max
import datetime
#from datetime import datetime, timedelta
import pdb
from models import quarter
#from datetime import datetime, timedelta

from django.http import HttpResponseRedirect,HttpResponse
from django.shortcuts import render, render_to_response
import easy_pdf
from easy_pdf.views import PDFTemplateView
# Create your views here.

def viewIndex(request):
	"""
		Here,we are checking is user is login or not.
		If user is already login into the app ,we are redirect to home page or else requesting login page
		action:{GET}
	"""	
	if 'samlUserdata' in request.session:
		if len(request.session['samlUserdata']) > 0:
			if 'Groups' in request.session['samlUserdata']:
				if 'Application.LaunchTool.Dev.NAA.PowerUser' in request.session['samlUserdata']['Groups'] or 'Application.LaunchTool.Dev.NAA.Administrator' in request.session['samlUserdata']['Groups'] or  'Application.LaunchTool.Dev.NAA.Viewer' in request.session['samlUserdata']['Groups']:
					return render_to_response('index1.html', {"request":request})
				else:
					return render_to_response('index.html', {"request":request})
			else:
				return render_to_response('index.html', {"request":request})
		else:
			return render_to_response('index.html', {"request":request})
	else:
		return render_to_response('index.html', {"request":request})
		#return HttpResponseRedirect('index.html')

class QuarterList(generics.ListCreateAPIView):
	"""
		Here,we are getting the list of dates with respect to seasons
		action:{GET}
	"""
	permission_classes = (IsAuthenticated,)
	queryset = quarter.objects.all()
	serializer_class = QuarterSerializer


class ScenarioList(generics.CreateAPIView):
	"""
		creating scenario planned by users
		action:{POST}
	"""
	permission_classes = (IsAuthenticated,)	
	def create(self, request, *args, **kwargs):
		request.data['user'] = request.session['userID']
		if 'Application.LaunchTool.Dev.NAA.PowerUser' in request.session['samlUserdata']['Groups']:
			serializer = ScenarioSerializer(data=request.data)
			serializer.is_valid(raise_exception=True)
			self.perform_create(serializer)
			headers = self.get_success_headers(serializer.data)
			return Response({'status':True,'response':serializer.data}, status=status.HTTP_201_CREATED, headers=headers)
		elif 'Application.LaunchTool.Dev.NAA.Administrator' in request.session['samlUserdata']['Groups'] and request.data['planning_folder'] != 5 or 'Application.LaunchTool.Dev.NAA.Viewer' in request.session['samlUserdata']['Groups'] and request.data['planning_folder'] != 5:
			serializer = ScenarioSerializer(data=request.data)
			serializer.is_valid(raise_exception=True)
			self.perform_create(serializer)
			headers = self.get_success_headers(serializer.data)
			return Response({'status':True,'response':serializer.data}, status=status.HTTP_201_CREATED, headers=headers)
		##elif 'Application.LaunchTool.Dev.NAA.Viewer' in request.session['samlUserdata']['Groups']:
		##	return Response({'status':False,'response':'No permissions to save the scenario'}, status=status.HTTP_201_CREATED)
		else:
			return Response({'status':False,'response':'No permissions to save the scenario'}, status=status.HTTP_201_CREATED)


		

class ScenarioListDetail(generics.RetrieveUpdateAPIView):
	"""
		Updating the sacenario and retrieving the single scenarion.
		action:{PUT, GET}
	"""
	permission_classes = (IsAuthenticated,)
	queryset = Planning.objects.all()
	serializer_class = ScenarioSerializer
	
class CadendenFolderListDetail(generics.ListAPIView):
	"""
		Getting all the folder list created by users.
		action:{GET}
	"""
	permission_classes = (IsAuthenticated,)
	queryset = PlanningFolder.objects.filter()
	serializer_class = PlanningFolderSerializer
	

class CadendenFolderDelete(APIView):
	"""
		Deleting the folder, and deleting the scenario cascaded to the respective folder.
		action:{DELETE}
	"""
	permission_classes = (IsAuthenticated,)
	def delete(self, request, pk, format=None):
		planning=PlanningFolder.objects.filter(pk=pk,access=0)
		if len(planning) > 0:
			planning.delete()
			return Response({'status':True})
		else:
			return Response({'status':False})

		
		
class CadendenPlanningDelete(APIView):
	"""
		Deleting the scenario.
		action:{DELETE}
	"""
	permission_classes = (IsAuthenticated,)
	def get_object(self, pk):
		try:
			return Planning.objects.get(pk=pk)
		except PlanningFolder.DoesNotExist:
			raise Http404
	
	def delete(self, request, pk, format=None):
		Planning = self.get_object(pk)
		Planning.delete()
		return Response({'status':True})
		


class CadendenFolderCreate(generics.CreateAPIView):
	permission_classes = (IsAuthenticated,)
	serializer_class = PlanningFolderDefaultSerializer



class TeradataList(APIView):
	"""
		Fetching all the shoe and slider data with respect to season.
		action:{GET}
	"""
	#permission_classes = (IsAuthenticated,)
	def post(self, request, format=None):
		if 'combination_key' in request.data and 'season' in request.data:
			start_date = datetime.datetime.today()
			current_season = quarter.objects.filter(start_date__gte=start_date).order_by('id').first()
			quarter_serializer = QuarterSerializer(current_season).data
			current_season_1 = quarter.objects.filter(season=quarter_serializer['season']).order_by('-id').first()
			current_season_1_serializer = QuarterSerializer(current_season_1).data
			
			if request.data['brand_name'] == "first":
				request.data['season'] = quarter_serializer['season']
			request_season = quarter.objects.filter(season=request.data['season']).order_by('-id').first()
			request_season_serializer = QuarterSerializer(request_season).data
			if request_season_serializer['id'] <= current_season_1_serializer['id']:
				request.data['combination_key'] = "0"
			else:
				combination_int_key = int(request.data['combination_key']) 
				if combination_int_key == 0:

					combination_teradata=CadenceTeradata.objects.filter(season=request.data['season']).first()
					#pdb.set_trace();
					combination_len = len(combination_teradata.combination_key)
					request.data['combination_key'] = '%0*d' % (combination_len, 0)
				else:
					combination_teradata=CadenceTeradata.objects.filter(season=request.data['season']).first()
					if len(request.data['combination_key']) != len(combination_teradata.combination_key):
						request.data['combination_key'] = combination_teradata.combination_key
			
			teradata = CadenceTeradata.objects.filter(combination_key=request.data['combination_key'],season=request.data['season'])
			data = TeradataSerializer1(teradata,many=True).data
			testmax = teradata.aggregate(Max('week_inv'))
			season_data = CadenceTeradata.objects.values('season','season_key','year_key').annotate(dcount=Count('season')).extra(select={'manual': "FIELD(season_key, 'SP', 'SU', 'FA', 'HO')"},order_by=['year_key','manual'])
			seasonArray=[]
			for season_value in season_data:
				seasonfilter=quarter.objects.filter(season=season_value['season'])
				quarter_date_serializer = QuarterSerializer(seasonfilter,many=True)
				seasonArray.append({"season_key":season_value,"season_weeks":quarter_date_serializer.data})
				
			season = []
			finalSeason = []
			brand_name = []
			if request.data['brand_name'] == 'first':
				category_selected = 'All'
			else:
				category_selected = request.data['brand_name']
				
			brand_name.append('All')
			for response1Test in data:
				launch_date = datetime.datetime.strptime(response1Test['launch_date'], '%m/%d/%Y')
				planned_launch_date = datetime.datetime.strptime(response1Test['planned_launch_date'], '%m/%d/%Y')
				response1Test['launch_date']=datetime.date.strftime(launch_date, "%Y-%m-%d")
				response1Test['planned_launch_date']=datetime.date.strftime(planned_launch_date, "%Y-%m-%d")
				if 'week_inv__max' in testmax:
					response1Test['frequency']=float(float(response1Test['week_inv'])/float(testmax['week_inv__max']));
				else:
					response1Test['frequency'] = 0

				if response1Test['brand_name'] not in brand_name:
					brand_name.append(response1Test['brand_name'])

			if 'Application.LaunchTool.Dev.NAA.Administrator' in request.session['samlUserdata']['Groups'] :
				is_admin=True;
			else:
				is_admin=False;
			#is_admin=False;
		
			return Response({"is_admin":is_admin,"response1":data,"season_data":seasonArray,"combination_key":request.data['combination_key'],"brand_name":brand_name,"season_selected":request.data['season'],"category_selected":category_selected,"combination_key":request.data['combination_key']})
		else:
			return Response({"status":False,'error':'Invalid post parameters'},status=status.HTTP_400_BAD_REQUEST)


def CadenceSave(request):
	start_date = datetime.datetime.strptime('2012-12-29','%Y-%m-%d')
	#tomorrow = start_date;
	end_date = datetime.datetime.strptime('2018-12-30','%Y-%m-%d')
	year_key=12
	seasons =['SP','SU','FA','HO']
	while start_date < end_date:
		year_key=year_key+1
		for season in seasons:
			for x in xrange(0,13):
				start_date = start_date+timedelta(days=7)
				year= str(start_date.year)
				quarter.objects.create(season=season + str(year_key),year_key=year_key,season_key=season,start_date=start_date,end_date=start_date)
	return HttpResponse(True)

class HelloPDFView(PDFTemplateView,APIView):
	"""
		Creating third page pdf with the post data.
		action:{POST}
	"""	
	template_name = "hello.html"
	pdf_filename = "Output.pdf"
	def post(self,request, format=None):
		context = { 'data'  : request.data}
		return  easy_pdf.rendering.render_to_pdf_response(request,  self.template_name, context, filename='Output.pdf', encoding=u'utf-8')


# CRON JOB
import pyodbc
def get_result(table):
	"""
	"""
	conn = pyodbc.connect('DRIVER={Teradata};DBCNAME=TeraProd;UID=ageor6;PWD=March2016;DATABASE=vdm_naa_t;')
	print "connection succ"
	curs = conn.cursor()
	print "curs set"
	query = 'select * from '+table
	print "query set"
	curs.execute(query)
	print " execute successful q"
	result = curs.fetchall()
	print result[0]
	print "fetch complete"
	#pdb.set_trace()
	conn.close()
	return result

def my_scheduled_job():
	"""
		Dumping the cannibalization_table from teradata VDM_NAA_T.LO_cannibalization_tool_input using cronjob.
		action:{DELETE}
	"""
	cannibalization_table = 'VDM_NAA_T.LO_cannibalization_tool_input'
	re = get_result(cannibalization_table)
	if len(re) > 0:
		CadenceCannibalization.objects.filter().delete()
		can_list = []
		for r in re:			
			can_list.append(CadenceCannibalization(stylclrcd=r[1],sub_category=r[0],takes1=r[2],takes2=r[3],gives1=r[4],gives2=r[5],time_stamp=r[6]))
		CadenceCannibalization.objects.bulk_create(can_list)	
	pass

def teradata_cron():
	"""
		Dumping the cadence_teradata from teradata vdm_naa_t.LO_tool_input_data using cronjob.
		action:{DELETE}
	"""
	tera_table = 'vdm_naa_t.LO_tool_input_data'
	
	te_result = get_result(tera_table)
	print "res"
	print len(te_result)
	t_list = []
	#pdb.set_trace()
	if len(te_result) > 0 :
		CadenceTeradata.objects.filter().delete()
		te_data_length = len(te_result)/500
		print te_data_length
		value1 = 0
		value2 = 499
		print "value1=",str(value1)
		j = 1
		for i in range(0, te_data_length+1):
			t_list=[]
			#print("range_for_loop")
			#print value2
			for d in te_result[value1:value2]:
				#print "for loop"
				ddd = d
				#pdb.set_trace()
				t_list.append(CadenceTeradata(id=j,combination_key=d[0],top_opportunity_flag=d[1],brand_name=d[2],style_name=d[3],stylclrcd=CadenceCannibalization(stylclrcd=d[4]),shoe_class=d[5],launch_date=d[6],season=d[7],day1_str=d[8],day1_sales=d[9],week1_str=d[10],week1_sales=d[11],total_inventory=d[12],msrp=d[13],prcnt_avg_mrkp=d[14],overall_launches=d[15],category_launches=d[16],overall_revenue=d[17],overall_tier_revenue=d[18],category_revenue=d[19],category_tier_revenue=d[20],overall_inv=d[21],overall_tier_inv=d[22],category_inv=d[23],category_tier_inv=d[24],overall_tier_day_str=d[25],category_tier_day_str=d[26],overall_tier_wk_str=d[27],category_tier_wk_str=d[28],week_inv=d[29],week_revenue=d[30],planned_launch_date=d[31],planned_inv=d[32],season_key=d[33],year_key=d[34],style_abbr=d[35],abbreviated_name=''))
				j = j+1
				
	##			CadenceTeradata.objects.create(combination_key=d[0],top_opportunity_flag=d[1],brand_name=d[2],style_name=d[3],stylclrcd=CadenceCannibalization(stylclrcd=d[4]),shoe_class=d[5],launch_date=d[6],season=d[7],day1_str=d[8],day1_sales=d[9],week1_str=d[10],week1_sales=d[11],total_inventory=d[12],msrp=d[13],prcnt_avg_mrkp=d[14],overall_launches=d[15],category_launches=d[16],overall_revenue=d[17],overall_tier_revenue=d[18],category_revenue=d[19],category_tier_revenue=d[20],overall_inv=d[21],overall_tier_inv=d[22],category_inv=d[23],category_tier_inv=d[24],overall_tier_day_str=d[25],category_tier_day_str=d[26],overall_tier_wk_str=d[27],category_tier_wk_str=d[28],week_inv=d[29],week_revenue=d[30],planned_launch_date=d[31],planned_inv=d[32],season_key=d[33],year_key=d[34],style_abbr=d[35],abbreviated_name='')
			#print "fgh"
			#pdb.set_trace()
			CadenceTeradata.objects.bulk_create(t_list)
			
			#print value1
			print value2
			print len(t_list)			
			value1 = value2
			value2 = value2 + 500
	pass


