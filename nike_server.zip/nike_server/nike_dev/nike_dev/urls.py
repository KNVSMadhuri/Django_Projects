from django.conf.urls import include, url
from django.contrib import admin
from django.contrib.auth.decorators import login_required
from cadence.views import *
from django.views.generic import TemplateView

urlpatterns = [
    # Examples:
    # url(r'^$', 'nike_dev.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')), 

   	url(r'^admin/', include(admin.site.urls)),
    url(r'^login$', TemplateView.as_view(template_name='login.html')),
    #url(r'^$',login_required(TemplateView.as_view(template_name='index.html'))),
   	#url(r'^$',TemplateView.as_view(template_name='index.html'))
   	url(r'^$', 'demo.views.index', name='index'),
   	url(r'^dasboard/$',viewIndex), 	
   	url(r'^o/', include('oauth2_provider.urls', namespace='oauth2_provider')),
   	url(r'^docs/', include('rest_framework_swagger.urls')),
   	url(r'^scenario/', include('cadence.urls')),
   	url(r'^saml/', include('demo.urls')),

    
]


