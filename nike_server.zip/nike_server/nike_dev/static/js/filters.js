angular.module('nikeApp').filter('brandFilter', function() {
  return function(input) {
  	console.log('hi');
  	console.log(input)
    //return input ? '\u2713' : '\u2718';
  };
}).filter('seasonSorter', function() {

  function CustomOrder(item) {
  	item = item.substring(0, 2);
    switch(item) {
      case 'SU':
        return 2;

      case 'SP':
        return 1;

      case 'HO':
        return 3;

      case 'FA':
        return 4;
    }  
  }

  return function(items, field) {
  	console.log(items);
  	console.log('item');
    var filtered = [];
    angular.forEach(items, function(item) {
      filtered.push(item);
    });
    filtered.sort(function (a, b) {    
      return (CustomOrder(a.class) > CustomOrder(b.class) ? 1 : -1);
    });
    return filtered;
  };
});