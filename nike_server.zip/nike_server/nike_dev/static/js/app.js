angular.module('nikeApp', [
    /*Angular Modules*/
    'ui.router',
    'directives',
    'darthwade.loading',


    //'ngResource'

]);
/*angular.module('nikeApp').filter('brandFilter', function() {
  return function(input) {
    console.log('dsd');
    console.log(input);
    //return input ? '\u2713' : '\u2718';
  };
});*/

angular.module('nikeApp').directive('hcStackedColumn', function() {
    return {
        restrict: 'E',
        template: '<div></div>',
        scope: {
            title: '@',
            data: '=',
            letter: '=',
            frequency: '='
        },
        link: function(scope, element) {
            Highcharts.chart(element[0], {
                chart: {
                    type: 'column'
                },
                title: {
                    text: ''
                },
                xAxis: {
                    categories: [''],
                    labels: {
                        enabled: false
                    },
                    title:{
                       text: '' 
                   },
                    lineColor: 'transparent',
                    tickLength: 0
                },
                yAxis: {
                    min: 0,
                    max: 1,
                    labels: {
                        enabled: false
                    },
                    title: {
                        text: ''
                    },
                    stackLabels: {
                        enabled: true,
                        verticalAlign:'bottom',
                         y: 15,
                        style: {
                            display:'none',
                            fontWeight: 'bold',
                            
                            color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                        }
                    }
                },
                legend: {
                    enabled: false,
                    align: 'right',
                    x: 2,
                    verticalAlign: 'top',
                    y: -5,
                    floating: true,
                    backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                    borderColor: '#CCC',
                    borderWidth: 1,
                    shadow: false
                },
               
                tooltip: {
                    headerFormat: '<b>{point.x}</b><br/>',
                    pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}',
                    enabled: false
                },

                plotOptions: {
                    column: {
                        stacking: 'normal',
                        dataLabels: {
                            enabled: false,
                            color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                            style: {
                                textShadow: '0 0 3px black'

                            }
                        }
                    }
                },
                series: [{
                    name: scope.letter,
                    data: [scope.frequency]
                }]
            });
        }
    };
})
