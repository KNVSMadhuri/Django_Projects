angular.module('directives', [])
    .directive('errSrc',function () {

        return{
            restrict: "A",
            link:function (scope, ele, attrs) {
                var defImage;
                ele.bind('error',function () {
                    console.log(attrs.errSrc);
                    console.log('asd');
                    switch(attrs.errSrc){
                        case 'JORDAN BRAND':
                            defImage = "/static/img/shoeimg/jordan_brand.png";
                            break;
                        case 'NIKE BASKETBALL':
                            defImage="/static/img/shoeimg/nike_baseketball.png";
                            break;
                        case 'NSW BASKETBALL':
                            defImage="/static/img/shoeimg/nsw_basketball.png";
                            break;

                    }
                    attrs.$set('src',defImage);


                })
            }
        }
    })
.directive('product', function($rootScope) {
    return {
        restrict: "E",
        transclude: true,
        scope:{
            obj:"=obj",
            comb:"@",
            func:"&",
            //roundValue:"="
        },
        templateUrl: "../static/views/components/titles.html",
        link: function($scope, elem, attrs) {
            //console.log($scope.combination_key);
            // console.log($scope.obj);
            $scope.ShowDescr = false;

            $('.product').click(function() {
                $('.POPdIV').find('.popUp').removeClass('disp');
                 $('.POPdIV').find('.product').removeClass('clickedIcon');
                  $('.POPdIV').find('.productName').removeClass('clickedIconName');
                $(this).parent().find('.popUp').addClass('disp');
                $(this).parent().find('.product').addClass('clickedIcon');
                $(this).parent().find('.productName').addClass('clickedIconName');
            });
            $('.close').click(function() {
                // $('.POPdIV').find('.popUp').removeClass('disp');
                $(this).parent().removeClass('disp');
            });
            $("body").click(function(event) {
                // $('.POPdIV').find('.product').removeClass('clickedIcon');
                if (!$(event.target).hasClass("toHide")) {
                // $('.POPdIV').find('.popUp').removeClass('disp'); 

                 
                }
            });

            
            $scope.roundValue =function(value){
                //alert('value');
                if(value < 800000){
                    value1 = value/1000;
                    roundValue = value1.toFixed(1) +'K';
                }else{
                    value1 = value/1000000;
                    roundValue = value1.toFixed(1) +'M';
                }
                return roundValue;
            }

            $scope.CheckGray=function(){
                if($rootScope.combination_key == localStorage.combination_key){
                    $rootScope.grayedOut = 0;
                }else{
                    $rootScope.grayedOut = 1;
                }
            }

            $scope.modifyCombination = function(obj){
                 $rootScope.oppurtunityTrue = true;          
                //obj.launch_flag='opportunity';
                $rootScope.combination_key = $rootScope.combination_key.substr(0, obj.top_opportunity_flag-1) + '1' + $rootScope.combination_key.substr(obj.top_opportunity_flag);
                $scope.CheckGray();
                //console.log($rootScope.combination_key);
                obj.combination_key=$rootScope.combination_key;
                //console.log($rootScope.combination_key);
                //$scope.func()(obj, 'opportunity');
            }
            $scope.impactGray=function(combination_key){
                
                /*if(combination_key == localStorage.combination_key){
                    return false;
                }else{
                    return true;
                }*/
                if($rootScope.grayedOut == 0){
                    return false;
                }else{
                    return true;
                }
            }
            $scope.impactUnit=function(opportunity,planned,flag){
                combination_value=$rootScope.combination_key.charAt(flag-1);
                if(combination_value==0){
                    impactValue = $scope.roundValue(planned)
                }else{
                    impactValue = $scope.roundValue(opportunity)
                }
                return impactValue;
                
            }

            $scope.modify1Combination = function(obj){
                //obj.launch_flag='planned';
                $rootScope.combination_key = $rootScope.combination_key.substr(0, obj.top_opportunity_flag-1) + '0' + $rootScope.combination_key.substr(obj.top_opportunity_flag);
                //console.log($rootScope.combination_key);
                $scope.CheckGray();
                $date=obj.launch_date;
                obj.combination_key=$rootScope.combination_key;
                //console.log($rootScope.combination_key);
                //$scope.func()(obj, 'planned');

            }

            $scope.check_planned_oppor=function(obj){
                /*console.log('kk');
                console.log(obj);*/
                obj.opportunityFlag=false;
                if(obj.top_opportunity_flag > 0){

                    var comb_key=obj.combination_key;
                    //var comb_key='123456';
                    var value=comb_key.substring(obj.top_opportunity_flag-1,obj.top_opportunity_flag);
                    //console.log(value);
                    if(value==1){
                        //alert(1)
                        obj.opportunityFlag=true;
                        obj.plannedflag=false;
                    }else{
                        //console.log(2)
                        //obj.opportunityFlag=false;
                        obj.plannedflag=true;
                    }
                }else{
                    obj.plannedflag=true;
                }
                $scope.ShowDescr = true;
                return true;
            }
            $scope.addHighlight = false;
            $scope.showShoePop=function(evt,obj){
                 //console.log(obj);
                 $scope.addHighlight = true;
                 $scope.valX = evt.clientX;
                 $scope.valY = evt.clientY;
                /*console.log($scope.valY);
                console.log($scope.valX);*/
                if($scope.valX<550 && $scope.valY<=320)
                {
                    $scope.qOne=true;
                    // console.log("1");
                }
                else if($scope.valX>550 && $scope.valY<=320)
                {
                    $scope.qTwo=true;
                    // console.log("2");
                }
                else if($scope.valX <= 550 && $scope.valY>320)
                {
                    $scope.qThree=true;
                    // console.log("3");
                }
                else if($scope.valX >= 550 && $scope.valY>320){
                    $scope.qFour=true;
                    //console.log("4");
                }


                // if($scope.valX >=530){
                //     $scope.displayLeft=true;
                //                     }
                // if($scope.valY >=153){
                //     $scope.displayTop=true;
                // }
                // else{
                //     $scope.displayDefault=true;
                // }

                //        $scope.ShowDescr = false;
                //     $scope.pops =  document.getElementsByClassName("popUp");
                //         $scope.leng = $scope.pops.length -1;
                
                //         console.log($scope.pops);

                //  console.log($scope.pops.length);


                //     console.log($scope.leng);
                // //  $scope.leng = $scope.pops.length;
                // $scope.pops[$scope.leng].style.display="none";
                // $scope.ShowDescr = true;


                    if(obj.stylclrcd){
                        if(obj.stylclrcd.takes2 == "-" && obj.stylclrcd.takes1 == "-" )
                        {
                            $scope.hidelevel2before = true;
                            // console.log("takes empty");
                            $(this).parent().find('.popUp').addClass('disp');
                            $(".row2").removeClass("row2center");
                            $(".row3").removeClass("row3right");

                            $(".row2").addClass("row2left");
                            $(".row3").addClass("row3center");
                        }
                        else{
                            $(".row2").removeClass("row2left");
                            $(".row3").removeClass("row3center");
                            $(".row2").addClass("row2center");
                            $(".row3").addClass("row3right");
                        }
                        if(obj.stylclrcd.gives1 == "-" && obj.stylclrcd.gives2 == "-" )
                        {
                            $scope.hidelevel2after = true;
                        }
                    }
                }

          
            $scope.hideDescr =function(){
            

                // console.log("hi");
                $scope.ShowDescr = false;
                $scope.addHighlight = false;
                //console.log($scope.ShowDescr);
            }

           
            
        }
    }
})


// .directive('graph', function() {
//     return {
//         restrict: "E",
//         transclude: true,
//         scope:{
//         },
//         template:"<div class='graph'></div>",
//         link: function(scope, elem, attrs) {
//             // console.log($scope.obj);
//         var margin = {
//             top: 10,
//             right: 10,
//             bottom: 30,
//             left: 10
//         },
//         width = 1100- margin.right - margin.left;
//         height = 100 - margin.top - margin.bottom;

//     var formatPercent = d3.format(".0%");

//     var x = d3.scale.ordinal()
//         .rangeRoundBands([0, width], .1);

//     var y = d3.scale.linear()
//         .range([height, 0]);

//     var xAxis = d3.svg.axis()
//         .scale(x)
//         .orient("bottom");

//     var yAxis = d3.svg.axis()
//         .scale(y)
//         .orient("left")
//         .tickFormat(formatPercent);

//     var tip = d3.tip()
//         .attr('class', 'd3-tip')
//         .offset([0, 0])
//         .html(function(d) {
//             return "<strong>Frequency:</strong> <span style='color:black'>" + d.frequency + "</span>";
//         })

//     var svg = d3.selectAll(".graph").append("svg")
//         .attr("width", width + margin.left + margin.right)
//         .attr("height", height + margin.top + margin.bottom)

//         .append("g")
//         .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

//     svg.call(tip);

//     // The new data variable.

// console.log(scope.obj);
// var data = [
//   {letter: "151K", frequency: .08167},
//   {letter: "121K", frequency: .01492},
//   {letter: "30K", frequency: .02780},
//   {letter: "52K", frequency: .04253},
//   {letter: "71K", frequency: .12702},
//   {letter: "56K", frequency: .02288},
//   {letter: "32K", frequency: .02022},
//   {letter: "45K", frequency: .06094},
//   {letter: "43K", frequency: .06973},
//   {letter: "76K", frequency: .00153},
//   {letter: "48K", frequency: .00747},
//   {letter: "90K", frequency: .04025},
//   {letter: "92K", frequency: .02517}
// ];
// console.log(data);
//     // The following code was contained in the callback function.
//     x.domain(data.map(function(d) {
//         return d.letter;
//     }));
//     y.domain([0, d3.max(data, function(d) {
//         return d.frequency;
//     })]);

//     svg.append("g")
//         .attr("class", "x axis")
//         .attr("transform", "translate(0," + height + ")")
//         .call(xAxis);

//     // svg.append("g")
//     //     .attr("class", "y axis")
//     //     .call(yAxis)
//     //     .append("text")
//     //     .attr("transform", "rotate(-90)")
//     //     .attr("y", 6)
//     //     .attr("dy", ".71em")
//     //     .style("text-anchor", "end")
//     //     .text("Frequency");

//     svg.selectAll(".bar")
//         .data(data)
//         .enter().append("rect")
//         .attr("class", "bar")

//         .attr("x", function(d) {
//             return x(d.letter);
//         })
//         .attr("width", x.rangeBand())
//         .attr("y", function(d) {
//             return y(d.frequency);
//         })
//         .attr("height", function(d) {
//             console.log(d,height - y(d.frequency))
//             return height - y(d.frequency);
//         })
//         // .on('mouseover', tip.show)
//         // .on('mouseout', tip.hide)

//     function type(d) {
//         d.frequency = +d.frequency;
//         return d;
//     };

//         }
//     }
// })
