/**
 * Defines routing configuration for nikeApp route from one state to another state
 * It allows only for valid states which is need to be define here.
 * @ngInject
 *
 */
angular.module('nikeApp').config(function ($stateProvider, $urlRouterProvider) {
    // For any unmatched url, redirect to /login
    $urlRouterProvider.otherwise("/dashboard");
    // Now set up the states
    $stateProvider
        .state('login', {
            url: "/login",
            views: {
                'content': {
                    templateUrl: "views/login.html",
                    controller: "loginController"
                }
            },
            cache: false
        })
        .state('dashboard', {
            url: "/dashboard",
            views: {
                'content': {
                    templateUrl: "../static/views/dashboard.html",
                    controller: "dashboardController"
                }
            },
            cache: false
        })
        .state('slider', {
            url: "/slider",
            views: {
                'content': {
                    templateUrl: "views/slider.html",
                    controller: "sliderController"
                }
            },
            cache: false
        })

});