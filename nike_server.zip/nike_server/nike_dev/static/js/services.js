//All your service Scripts
angular.module('nikeApp').service("query", function($http, $state) {

     // var base = "http://nke-lnx-naa-t001:3000/";
    //var base = "http://10.199.18.124:3000/";
   var base = "/";
	//http://nke-lnx-naa-t001:3000

    this.get = function(url, callback) {
        $http({
            method: 'GET',
            //url: base+url+"?access_token="+localStorage.accesstoken,
            url: base + url,
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(function(data) {
            callback(data);
        }, function(err) {
            callback(err);
        })
    }
    this.delete = function(url, callback) {
        $http({
            method: 'DELETE',
            //url: base+url+"?access_token="+localStorage.accesstoken,
            url: base + url,
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(function(data) {
            callback(data);
        }, function(err) {
            callback(err);
        })
    }
    this.post = function(url, data, callback) {
        $http({
            method: 'POST',
            //url: base+url+"?access_token="+localStorage.access_token,
            url: base + url,
            data: data,
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(function(data) {
            callback(data);
        }, function(err) {
            callback(err);
        })
    }
    this.put = function(url, data, callback) {
        $http({
            method: 'PUT',
            url: base + url,
            data: data,
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(function(data) {
            callback(data);
        }, function(err) {
            callback(err);
        })
    }
    this.formData = function(url, data, callback) {
        $http({
            method: 'POST',
            //url: base+url+"?access_token="+localStorage.access_token,
            url: base + url,
            data: data,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(function(data) {
            callback(data);
        }, function(err) {
            callback(err);
        })
    }
})


angular.module('playApp').service("userSession", function () {
    var isLoggedIn = false;
    this.checkUser = function () {
        if (localStorage.accesstoken) {
            return true;
        } else {
            return false;
        }
    }
    this.setLoginStat = function (state) {
        isLoggedIn = state;
    }
})
