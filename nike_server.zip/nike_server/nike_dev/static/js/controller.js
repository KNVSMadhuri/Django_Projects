angular.module('nikeApp').controller("loginController", ['$scope', function loginController($scope) {

}]);

angular.module('nikeApp').controller("dashboard1Controller",['$scope',function dashboard1Controller($scope){

}]);
angular.module('nikeApp').controller("graphController", ['$scope', function graphController($scope) {
}]);

angular.module('nikeApp').controller("dashboardController", ['$window','$http','$scope','$rootScope','query','$rootScope','$state','$filter','$loading','$timeout',function dashboardController($window,$http,$scope,$rootScope,query,$rootScope,$state,$filter,$loading,$timeout) {

    // $scope.stackedColumnData = ['Friendly Rivals', 'Connoisseurs', 'Indulgers', 'Connectors', 'Dreamers', 'Dabblers'];
    
    $('#printDiv').hide();
    $rootScope.combination_key ='';
    $rootScope.oppurtunityTrue = false;
    $scope.dashboardResponse='';
    $scope.dashboardGraphProduct='';
    $scope.fnIconClick = false;
    $scope.showSave = false;
    $scope.showOpen = false;
    $scope.ShowDescr = false;
    $rootScope.grayedOut=0;

    $scope.sliderResult = '';

    $scope.teradataRequest= function(postBody){
        $loading.start('teradataLoader');
        query.post('scenario/teradata/', postBody, function (r) {
            console.log(r.data);
            if (r.status == 200 || r.status == 201) {
                $loading.finish('teradataLoader');
                $scope.dashboardResponse = r.data;
                $rootScope.combination_key = r.data['combination_key'];
                $rootScope.grayedOut=0;
                localStorage.setItem("combination_key",r.data['combination_key']);
                //localStorage.setItem("dashboardResponse", JSON.stringify($scope.dashboardResponse));
                $scope.listDateArray($scope.dashboardResponse['season_selected'],$scope.dashboardResponse)
                //$scope.dashboardGraphProduct = $scope.getBetweenDayTeradata('2016-12-28','2017-04-01',r.data);
                localStorage.setItem("dashboardGraphProduct", JSON.stringify($scope.dashboardGraphProduct));
                $timeout(function(){
                    if(!($(".styled-select-1").attr( "style" )&&$(".styled-select-1").find('.select1'))){
                        if($.browser.mozilla){
                            $(".styled-select-1").css({width:$('.select1 > option').width()+50+'px'})  
                        $(".styled-select-1").find('.select1').css({width:$('.select1 > option').width()+50+'px'})  
                        }else{
                             $(".styled-select-1").css({width:$('.select1').width()+50+'px'})  
                        $(".styled-select-1").find('.select1').css({width:$('.select1').width()+50+'px'})  
                        }
                        

                        
                    }

                    if(!($(".styled-select-2").attr( "style" )&&$(".styled-select-2").find('.select2'))){
                        if($.browser.mozilla){
                        $(".styled-select-2").css({width:$('.select2 > option').width()+50+'px'})  
                        $(".styled-select-2").find('.select2').css({width:$('.select2 > option').width()+50+'px'})  
                    }else{

                         $(".styled-select-2").css({width:$('.select2').width()+50+'px'})  
                        $(".styled-select-2").find('.select2').css({width:$('.select2').width()+50+'px'})
                    }
                    }
                     
                },500)
                //$scope.sliderResult = $scope.tersdataSliderObject(r.data);
                
            }
        });
    }

    $scope.productBrandObj=function(brand_name){
        brandObject ={}
        brandObject.brand = brand_name;
        return brandObject;
                               
    }

    $scope.selectedSeasonValue='';
    $scope.selectedSeasonArray=function(selected_season,season){
        obj={}
        angular.forEach(season,function(value,key){
            if(value['season_key']['season']==selected_season){
                obj= value['season_key'];
            }
        });
        return obj;
            
    }

    // $scope.showOptions = function(){
    //     // console.log(x);
    //     $("#d1").trigger( "click" );
    // }

//     $scope.eventFire = function (el, etype){
//   if (el.fireEvent) {
//     el.fireEvent('on' + etype);
//   } else {
//     var evObj = document.createEvent('Events');
//     evObj.initEvent(etype, true, false);
//     el.dispatchEvent(evObj);
//   }
// }

$(".fa-chevron-circle-down").click(function(){
    $scope.openDD($(this).parent().find("select"))
})

$scope.openDD = function(elem) {
    if (document.createEvent) {
        var e = document.createEvent("MouseEvents");
        e.initMouseEvent("mousedown", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        elem[0].dispatchEvent(e);
    } else if (element.fireEvent) {
        elem[0].fireEvent("onmousedown");
    }
}

    $scope.listDateArray1=function(selected_season,response){
        $scope.selectedSeasonValue=$scope.selectedSeasonArray(selected_season,response['season_data']);
        $scope.seasonCombdata = {};
        $scope.seasonCombdata.combination_key = $rootScope.combination_key;
        $scope.seasonCombdata.season = $scope.dashboardResponse.season_selected;
        $scope.seasonCombdata.brand_name = $scope.dashboardResponse.category_selected;
        $scope.seasonCombdata.season_key = $scope.selectedSeasonValue['season_key'];
        $scope.seasonCombdata.year_key = $scope.selectedSeasonValue['year_key'];
        console.log($scope.seasonCombdata);
        console.log('fgh');
        $scope.loadedCadenceTeradata = undefined;
        $rootScope.grayedOut=0;
        $scope.teradataRequest($scope.seasonCombdata);


    }

    $scope.listDateArray=function(selected_season,response){
        $scope.selectedSeasonValue=$scope.selectedSeasonArray(selected_season,response['season_data']);
        console.log($scope.selectedSeasonValue);
        console.log('selected_value');
        listDateObj={}
        teradatSlider = {};
        teradatSlider.overall={};
        teradatSlider.category=[];
        teradatSlider.categoryRef=[];
        angular.forEach(response['season_data'],function(value,key){
            if(selected_season == value['season_key']['season']){
                angular.forEach(value['season_weeks'],function(dateValue,dateKey){
                    dateValue['product']=[];
                    dateValue['brand_name'] = [];
                    angular.forEach(response['response1'],function(productValue,productKey){
                        var combination_value=$rootScope.combination_key.charAt(productValue['top_opportunity_flag']-1);
                        if(dateValue['season']==productValue['season']){
                            
                            if(productValue['top_opportunity_flag'] == '0' && productValue['planned_launch_date']== dateValue['start_date']){
                                dateValue['frequency']=productValue['frequency'];
                                dateValue['week_inv']=productValue['week_inv'];
                                dateValue['week_revenue']=productValue['week_revenue'];
                                productValue.logo = "img/Shoe1.png";
                                if(productValue['brand_name'] == 'JORDAN BRAND'){
                                  productValue.isPink= true;
                                }
                                else if(productValue['brand_name'] == 'NIKE BASKETBALL'){
                                    productValue.isBlue= true;
                                }else{
                                    productValue.isGrey= true;
                                }
                                dateValue['brand_name'].push($scope.productBrandObj(productValue['brand_name']));
                                dateValue['product'].push(productValue)
                            }
                            else if (combination_value == 1 &&  productValue['launch_date']== dateValue['start_date']){
                                dateValue['frequency']=productValue['frequency'];
                                dateValue['week_inv']=productValue['week_inv'];
                                dateValue['week_revenue']=productValue['week_revenue'];
                                productValue.logo = "img/Shoe1.png";
                                if(productValue['brand_name'] == 'JORDAN BRAND'){
                                  productValue.isPink= true;
                                }
                                else if(productValue['brand_name'] == 'NIKE BASKETBALL'){
                                    productValue.isBlue= true;
                                }else{
                                    productValue.isGrey= true;
                                }
                                dateValue['brand_name'].push($scope.productBrandObj(productValue['brand_name']));
                                dateValue['product'].push(productValue)
                            }
                            else if (combination_value != 1 &&  productValue['planned_launch_date']== dateValue['start_date']){
                                dateValue['frequency']=productValue['frequency'];
                                dateValue['week_inv']=productValue['week_inv'];
                                dateValue['week_revenue']=productValue['week_revenue'];
                                productValue.logo = "img/Shoe1.png";
                                if(productValue['brand_name'] == 'JORDAN BRAND'){
                                  productValue.isPink= true;
                                }
                                else if(productValue['brand_name'] == 'NIKE BASKETBALL'){
                                    productValue.isBlue= true;
                                }else{
                                    productValue.isGrey= true;
                                }
                                dateValue['brand_name'].push($scope.productBrandObj(productValue['brand_name']));
                                dateValue['product'].push(productValue)
                            }

                            teradatSlider.overall['overall_inv'] =productValue['overall_inv'];
                            teradatSlider.overall['overall_launches'] =productValue['overall_launches'];
                            teradatSlider.overall['overall_revenue'] =productValue['overall_revenue'];
                            if(productValue['shoe_class'] == 'GOLD'){
                                teradatSlider.overall.gold =$scope.currentOverallYearData('GOLD',productValue);
                                teradatSlider.overall.gold_last =$scope.commonLastOverallYearData('GOLD',productValue.last);
                            }
                            else if(productValue['shoe_class'] == 'PLATINUM'){
                                teradatSlider.overall.platinum =$scope.currentOverallYearData('PLATINUM',productValue);
                                teradatSlider.overall.platinum_last =$scope.commonLastOverallYearData('PLATINUM',productValue.last);
                            }

                            if (teradatSlider.categoryRef.indexOf(productValue['brand_name']+productValue['shoe_class']) == -1 ) {
                                category = {}
                                category.category_name = productValue['brand_name'];
                                category.category_inv =productValue['category_inv'];
                                category.category_launches =productValue['category_launches'];
                                category.category_revenue =productValue['category_revenue'];
                                if(productValue['shoe_class'] == 'GOLD'){
                                    category.gold =$scope.currentCategoryYearDataArr('GOLD',productValue);
                                    category.gold_last =$scope.commonLastCategoryYearData(productValue.brand_name,'GOLD',productValue.last);
                                }
                                else if(productValue['shoe_class'] == 'PLATINUM'){
                                    category.platinum =$scope.currentCategoryYearDataArr('PLATINUM',productValue);
                                    category.platinum_last =$scope.commonLastCategoryYearData(productValue.brand_name,'PLATINUM',productValue.last);
                                    
                                }
                                teradatSlider.category.push(category);
                                teradatSlider.categoryRef.push(productValue['brand_name']+productValue['shoe_class']);
                            }

                        }
                    });
                });
                listDateObj.current_season = value['season_weeks'];
                listDateObj.overall = teradatSlider;
                listDateObj.overall.category = $scope.uniqueBrand(listDateObj.overall.category);
                $scope.seasonDateArray= listDateObj;
            }
        });
        console.log($scope.seasonDateArray);
        console.log('hi');
    }

    $scope.uniqueBrand=function(categoryBrand){
        brand = [];
        classes =[];
        category=[];
        angular.forEach(categoryBrand,function(value,key){
            if (brand.indexOf(value['category_name']) == -1 ) {
                if(typeof value['gold'] != 'undefined'){
                    angular.forEach(categoryBrand,function(value1,key1){
                            if(value1['platinum'] && value['category_name']==value1['category_name']){
                                value.platinum=value1['platinum'];
                                value.platinum_last=value1['platinum_last'];
                            }

                    });
                    value.gold=value['gold'];
                    value.gold_last=value['gold_last'];
                }else{
                    angular.forEach(categoryBrand,function(value1,key1){
                            if(value1['gold'] && value['category_name']==value1['category_name']){
                                value.gold=value1['gold'];
                                value.gold_last=value1['gold_last'];
                            }
                            

                    });
                    value.platinum=value['platinum'];
                    value.platinum_last=value['platinum_last'];
                }
                
                category.push(value)
                brand.push(value['category_name']);
            }

        })

        return category;

    }

    $scope.previousAltData=function(last_season,last_year_data,currency){
        if(isNaN(last_year_data)){
            return 'No Data';

        }else{
            if(currency == '$'){
                return last_season+ ': '+ currency + $scope.roundValue(last_year_data);
            }
            else if(currency == '%'){
                return last_season+ ': '+ $filter('number')(last_year_data,0)+ currency ;
            }else{
                return last_season+ ': ' + $scope.roundValue(last_year_data);
            }
        }
    }

    $scope.commonLastOverallYearData = function(shoe_class,last_year_data){
        //console.log(last_year_data);
        overallObj={}
        angular.forEach(last_year_data,function(last_value,last_key){
            if(last_value['shoe_class'] == shoe_class){
                overallObj.overall_tier_day_str =last_value['overall_tier_day_str'];
                overallObj.overall_tier_inv =last_value['overall_tier_inv'];
                overallObj.overall_tier_revenue =last_value['overall_tier_revenue'];
                overallObj.overall_tier_wk_str =last_value['overall_tier_wk_str'];
                overallObj.season =last_value['season'];
                keepGoing = false;
            }
        });
        return overallObj;
    }

    $scope.commonLastCategoryYearData = function(brand_name,shoe_class,last_year_data){
        categoryObj={}
        angular.forEach(last_year_data,function(last_value,last_key){
            if(last_value['shoe_class'] == shoe_class && last_value['brand_name'] == brand_name){
                categoryObj.category_tier_day_str =last_value['category_tier_day_str'];
                categoryObj.category_tier_inv =last_value['category_tier_inv'];
                categoryObj.category_tier_revenue =last_value['category_tier_revenue'];
                categoryObj.category_tier_wk_str =last_value['category_tier_wk_str'];
                categoryObj.season =last_value['season'];
                keepGoing = false;
            }
        });
        return categoryObj;
    }

    $scope.currentOverallYearData=function(shoe_class,current_season_data){
        overallObj={}
        overallObj.overall_tier_day_str =current_season_data['overall_tier_day_str'];
        overallObj.overall_tier_inv =current_season_data['overall_tier_inv'];
        overallObj.overall_tier_revenue =current_season_data['overall_tier_revenue'];
        overallObj.overall_tier_wk_str =current_season_data['overall_tier_wk_str'];
        overallObj.season =current_season_data['season'];
        return overallObj;
    }

    $scope.currentCategoryYearDataArr=function(shoe_class,current_season_data){
        overallObj={}
        overallObj.category_tier_day_str =current_season_data['category_tier_day_str'];
        overallObj.category_tier_inv =current_season_data['category_tier_inv'];
        overallObj.category_tier_revenue =current_season_data['category_tier_revenue'];
        overallObj.category_tier_wk_str =current_season_data['category_tier_wk_str'];
        overallObj.season =current_season_data['season'];
        return overallObj;
    }

    $scope.currentCategoryYearData=function(brand_name,shoe_class,current_season_data){
        overallObj={}
        angular.forEach(current_season_data,function(last_value,last_key){
            if(last_value['shoe_class'] == shoe_class && last_value['brand_name'] == brand_name){
                overallObj.category_tier_day_str =last_value['category_tier_day_str'];
                overallObj.category_tier_inv =last_value['category_tier_inv'];
                overallObj.category_tier_revenue =last_value['category_tier_revenue'];
                overallObj.category_tier_wk_str =last_value['category_tier_wk_str'];
                overallObj.season =last_value['season'];
                keepGoing = false;
            }
        });
        return overallObj;
    }


    $scope.orderByseason = function(season){

        /*console.log(season);
        console.log('season');*/

    }


    

   /* $scope.tersdataSliderObject = function(terdataResponse){
        teradatSlider = {};
        teradatSlider.overall={};
        teradatSlider.categoryRef=[];
        teradatSlider.category=[];
        angular.forEach(terdataResponse.response,function(value,key){
            value['overall_inv'] = value['overall_inv'];
            value['overall_revenue'] = value['overall_revenue'];
            value['overall_tier_inv'] = value['overall_tier_inv'];
            value['overall_tier_revenue'] = value['overall_tier_revenue'];
            value['category_inv'] = value['category_inv'];
            value['category_revenue'] = value['category_revenue'];
            value['category_tier_inv'] = value['category_tier_inv'];
            value['category_tier_revenue'] = value['category_tier_revenue'];
           

            teradatSlider.overall.overall_inv =value['overall_inv'];
            teradatSlider.overall.overall_launches =value['overall_launches'];
            teradatSlider.overall.overall_revenue =value['overall_revenue'];
                
            if(value['shoe_class'] == 'GOLD'){
                teradatSlider.overall.gold = {};
                //teradatSlider.overall.gold_last = {};
                teradatSlider.overall.gold_last =$scope.commonLastOverallYearData('GOLD',terdataResponse.last_year_data);
                teradatSlider.overall.gold.overall_tier_day_str =value['overall_tier_day_str'];
                teradatSlider.overall.gold.overall_tier_inv =value['overall_tier_inv'];
                teradatSlider.overall.gold.overall_tier_revenue =value['overall_tier_revenue'];
                teradatSlider.overall.gold.overall_tier_wk_str =value['overall_tier_wk_str'];
            }
            else if(value['shoe_class'] == 'PLATINUM'){
                teradatSlider.overall.platinum = {}
                teradatSlider.overall.platinum_last =$scope.commonLastOverallYearData('PLATINUM',terdataResponse.last_year_data);
                teradatSlider.overall.platinum.overall_tier_day_str =value['overall_tier_day_str'];
                teradatSlider.overall.platinum.overall_tier_inv =value['overall_tier_inv'];
                teradatSlider.overall.platinum.overall_tier_revenue =value['overall_tier_revenue'];
                teradatSlider.overall.platinum.overall_tier_wk_str =value['overall_tier_wk_str'];
            }
            

            if (teradatSlider.categoryRef.indexOf(value['brand_name']) == -1) {
                    category = {}
                    category.category_name = value['brand_name'];
                    category.category_inv =value['category_inv'];
                    category.category_launches =value['category_launches'];
                    category.category_revenue =value['category_revenue'];
                    if(value['shoe_class'] == 'GOLD'){
                        category.gold = {}
                        category.gold_last =$scope.commonLastCategoryYearData(value['brand_name'],'GOLD',terdataResponse.last_year_data);
                        category.gold.category_tier_day_str =value['category_tier_day_str'];
                        category.gold.category_tier_inv =value['category_tier_inv'];
                        category.gold.category_tier_revenue =value['category_tier_revenue'];
                        category.gold.category_tier_wk_str =value['category_tier_wk_str'];
                        angular.forEach(terdataResponse.response,function(value1,key1){
                            if(value1['brand_name'] == value['brand_name'] && value1['shoe_class'] == 'PLATINUM'){
                                category.platinum = {}
                                category.platinum_last =$scope.commonLastCategoryYearData(value['brand_name'],'PLATINUM',terdataResponse.last_year_data);
                                category.platinum.category_tier_day_str =value1['category_tier_day_str'];
                                category.platinum.category_tier_inv =value1['category_tier_inv'];
                                category.platinum.category_tier_revenue =value1['category_tier_revenue'];
                                category.platinum.category_tier_wk_str =value1['category_tier_wk_str'];
                                keepGoing = false;
                            }
                        });
                    }else{
                        category.platinum = {}
                        category.platinum_last =$scope.commonLastCategoryYearData(value['brand_name'],'PLATINUM',terdataResponse.last_year_data);
                        category.platinum.category_tier_day_str =value['category_tier_day_str'];
                        category.platinum.category_tier_inv =value['category_tier_inv'];
                        category.platinum.category_tier_revenue =value['category_tier_revenue'];
                        category.platinum.category_tier_wk_str =value['category_tier_wk_str'];
                        angular.forEach(terdataResponse.response,function(value1,key1){
                            if(value1['brand_name'] == value['brand_name'] && value1['shoe_class'] == 'GOLD'){
                                category.gold = {}
                                category.gold_last =$scope.commonLastCategoryYearData(value['brand_name'],'GOLD',terdataResponse.last_year_data);
                                category.gold.category_tier_day_str =value1['category_tier_day_str'];
                                category.gold.category_tier_inv =value1['category_tier_inv'];
                                category.gold.category_tier_revenue =value1['category_tier_revenue'];
                                category.gold.category_tier_wk_str =value1['category_tier_wk_str'];
                                keepGoing = false;
                            }
                        });
                    }
                    teradatSlider.category.push(category);
                    teradatSlider.categoryRef.push(value['brand_name']);
                }
            });
console.log(teradatSlider);
            
    return teradatSlider; 

    }*/

    $scope.roundValue =function(value){
        //alert('value');
        if(value < 800000){
            value1 = value/1000;
            roundValue = value1.toFixed(1) +'K';
        }else{
            value1 = value/1000000;
            roundValue = value1.toFixed(1) +'M';
        }
        return roundValue;
    }
    $scope.roundValue1 =function(value){
        /*console.log(123)
        console.log(value);*/
    }
    $scope.data = {};
    $scope.data.combination_key = "0";
    $scope.data.season = 'SU16';
    $scope.data.year_key = '16';
    $scope.data.season_key = 'SU';
    $scope.data.season = 'SU16';
    $scope.data.brand_name = 'first';
    $scope.data.season_key = 'SU';
    $scope.data.year_key = '16';
    $scope.teradataRequest($scope.data);
    
        
    query.get('scenario/quarter/', function (r) {
            if (r.status == 200) {
                //$loading.finish('scenario');
                console.log(r.data);
            }
        });

// $("html body section").click(function(event) {
//                 if (!$(event.target).hasClass("showInfo")) {
//                    $('.hovertitle').find('.info').removeClass('disp'); 
//                 }
//             });

    $scope.nikeExecute= function(){
        $scope.data = {};
        $scope.data.combination_key = $rootScope.combination_key;
        $scope.data.season = $scope.dashboardResponse.season_selected;
        $scope.data.brand_name = $scope.dashboardResponse.category_selected;
        $scope.data.season_key = $scope.selectedSeasonValue['season_key'];
        $scope.data.year_key = $scope.selectedSeasonValue['year_key'];
        $rootScope.oppurtunityTrue = false;
        $scope.teradataRequest($scope.data);
    }

    $scope.percentageCalulation=function(percentageValue){


        var perValue= percentageValue *100;
        if(perValue){
            return $filter('number')(perValue,0) + '%'
        }else{
            return '0%'
        }
        





    }

     



    $scope.showPop = function(x) {
        $scope.ShowDescr = false;
        var type = x;
        if (type == "save") {
            $scope.showSave = true;
            $scope.showOpen = false;
        } else {
            $scope.showOpen = true;
            $scope.showSave = false;
        }
        $scope.fnIconClick = true;;
        $scope.showFullLay = true;
    }
   
// $scope.selectRow = function (){
//     $scope.hilite = false;
//  var table = document.getElementById('dataTable');
//  for (var i=0;i < table.rows.length;i++){

//   table.rows[i].onclick= function () {
//    if(!this.hilite){
//     unhighlight();
//     this.origColor=this.style.backgroundColor;
//     this.style.backgroundColor='#BCD4EC';
//     this.hilite = true;
//    }
//    else{
//     this.style.backgroundColor=this.origColor;
//     this.hilite = false;
//    }
//     }
//  }
// }

// function unhighlight(){
//  var table = document.getElementById('dataTable');
//  for (var i=0;i < table.rows.length;i++){
//    var row = table.rows[i];
//    row.style.backgroundColor=this.origColor;
//    row.hilite = false;
//  }
// }

    var sliderOut = document.getElementById("slideout");
    var sliderIn = document.getElementById("slideout_inner");
    $scope.slideDisp = false;

    $scope.slideout = function() {

        if ($scope.slideDisp == false) {

            $scope.slideDisp = true;

            $scope.showOverLay = true;

            sliderOut.style.right = "650px";

            sliderIn.style.right = "0px";
            document.getElementById("dragIcon").style.transform = "rotate(180deg)";

        } else {
            $scope.slideoutClose();
        }
        $('.POPdIV').find('.popUp').removeClass('disp'); 
    }
    $scope.slideoutClose = function() {
        $scope.slideDisp = false;
        $scope.showOverLay = false;
        
        sliderOut.style.right = "0";
        sliderIn.style.right = "-650px";
        document.getElementById("dragIcon").style.transform = "rotate(0deg)";
    }

    

    $scope.selectedRow = null;
    
    $scope.setClickedRow = function(index,cadence,detailCadence){  

        $scope.selectedRow = index;
        $scope.cadenceRow =cadence;

    }

    $scope.viewCadenceResponse = '';



    $scope.cadenceRequest = function(){
        $loading.start('popUpLoader');
        query.get('scenario/', function (r) {
            if (r.status == 200) {
                $loading.finish('popUpLoader');
                $scope.viewCadenceResponse=r.data;
                
            }
        });
    }
    
    $scope.viewCadence=function(){
        $scope.selectedRow = null;
        $scope.nowAdding = false;
         $scope.isLoad = false;
        $scope.data.folderData = "";
        $scope.ifNewErr = false;
        $scope.cadenceRequest();
        $scope.showPop('save');
        
    }
    $scope.ifNewErr = false;
    $scope.data = {}
    $scope.data.folderData = "";

    $scope.removeFolder = function(data,index){
            console.log(data,index);
             var r = confirm("Are you sure you want to delete the folder ' "+data.folder_name+" '");
             if(r){
                query.delete("scenario/deleteFolder/"+data.id+"/",function(res){
                if(res.status == 201 || res.status==200) {
                        $scope.viewCadenceResponse.splice(index,1);
                    }
            });
             }

            
    }
    $scope.removeScenario = function(data,index){
            console.log(data,index);
             var r = confirm("Are you sure you want to delete the scenario ' "+data.cadence_planning_name+" '");
             if(r){
                    query.delete("scenario/deleteCadencePlanning/"+data.id+"/",function(res){
                    if(res.status == 201 || res.status==200) {
                            $scope.plannigFiles.splice(index,1);
                        }
                });
             }

            
    }

    $scope.createFolder = function(data){
       
        if($scope.nowAdding){
            if(!data){
                $scope.folder_err = "Please enter the folder name";
                $scope.ifNewErr = true;
            }else{
                $scope.data.folderData = "";
                $scope.ifNewErr = false;
                console.log($scope.viewCadenceResponse)
                 query.post("scenario/createFolder/",{"folder_name":data},function(res){
                    if(res.status == 201 || res.status==200) {
                        $scope.viewCadenceResponse.push(res.data)

                    }else{
                        if(res.status == 400){
                            $scope.folder_err = "The folder that you are trying to add already exist, please use use some other name";
                            $scope.ifNewErr = true;  
                        }
                    }
                 })
            }
            
           
        }else{
            
            $scope.closePop()
        }
    }
    $scope.isLoad = false;
    $scope.loadCadence = function(){
        $scope.selectedRow = null;
        $scope.nowAdding = false;
        $scope.ifNewErr = false;
        $scope.isLoad = true;
        $scope.data.folderData = "";
        $scope.cadenceRequest();
        $scope.showPop('load');
    }
    $scope.nowAdding = false;
    $scope.addNew = function(){
        $scope.nowAdding = true;

    }

    $scope.saveCadence= function(addCadence){
        //console.log($scope.selectedSeasonValue['season_key']);
        $scope.cadenceData ={}
        $scope.scenarioerror=false;
        
        if(addCadence==undefined){
            
            $scope.scenarioerror=true;
            $scope.cadence_planning_name_error='Please enter scenario name';

        }else if(addCadence.cadence_planning_name == '' || addCadence.cadence_planning_name == null){
            
            $scope.scenarioerror=true;
            $scope.cadence_planning_name_error='Please enter scenario name';
            
        }else{

            $scope.scenarioerror=false;
            $scope.cadenceData.cadence_planning_name = addCadence.cadence_planning_name;
            $scope.cadenceData.season = $scope.dashboardResponse.season_selected;
            $scope.cadenceData.Brand_name = $scope.dashboardResponse.category_selected;
            $scope.cadenceData.planning_folder = $scope.planningBrand_id;
            $scope.cadenceData.combination_key = $rootScope.combination_key;
            $scope.cadenceData.Year_Key = $scope.selectedSeasonValue['year_key'];
            $scope.cadenceData.season_Key = $scope.selectedSeasonValue['season_key'];
            $scope.cadenceData.user =2;
            $loading.start('popUpLoader');
            query.post('scenario/senarioSave/', $scope.cadenceData, function (r) {
                if (r.status == 200 || r.status == 201) {
                    $loading.finish('popUpLoader');
                    console.log(r.data);
                    var response=r.data.response;
                    if(r.data.status == true){
                        $scope.loadedCadenceTeradata ={};
                        $scope.loadedCadenceTeradata.id = response.id;
                        $scope.loadedCadenceTeradata.cadence_planning_name= response.cadence_planning_name;
                        $scope.loadedCadenceTeradata.season= response.season;
                        $scope.loadedCadenceTeradata.category_selected= response.Brand_name;
                        $scope.loadedCadenceTeradata.combination_key= response.combination_key;
                        $scope.loadedCadenceTeradata.Year_Key= response.Year_Key;
                        $scope.loadedCadenceTeradata.season_Key= response.season_Key;
                        $scope.loadedCadenceTeradata.user_id= response.user;
                        $scope.loadedCadenceTeradata.planning_folder_id= response.planning_folder;
                        $scope.closePop();
                    }else{
                        $scope.scenarioerror=true;
                        $scope.cadence_planning_name_error=response;
                    }
                        
                    
                }
                else{
                    $loading.finish('popUpLoader');
                    console.log(r.data.non_field_errors);
                    $scope.scenarioerror=true;
                    $scope.cadence_planning_name_error=r.data.non_field_errors[0];
                    
                    
                }
            });

        }


    }

    $scope.updateCadenceTeradta= function(){
        $scope.nowAdding = false;
        $scope.selectedRow = null;
        $scope.ifNewErr = false;
        $scope.isLoad = false;
        $scope.data.folderData = "";
        if($scope.loadedCadenceTeradata == undefined){
            
            $scope.cadenceRequest();
            $scope.showPop('save');
        }else{
            $scope.updateCadenceData ={}
            //$scope.cadenceData.season = addCadence.season;
            $scope.updateCadenceData.cadence_planning_name = $scope.loadedCadenceTeradata.cadence_planning_name;
            $scope.updateCadenceData.season = $scope.loadedCadenceTeradata.season;
            $scope.updateCadenceData.Brand_name = $scope.dashboardResponse.category_selected;
            $scope.updateCadenceData.combination_key = $rootScope.combination_key;
            $scope.updateCadenceData.year_key = $scope.loadedCadenceTeradata.Year_Key;
            $scope.updateCadenceData.season_Key = $scope.loadedCadenceTeradata.season_Key;
            $scope.updateCadenceData.user =$scope.loadedCadenceTeradata.user_id;
            $scope.updateCadenceData.planning_folder =$scope.loadedCadenceTeradata.planning_folder_id;
            
            //console.log($scope.loadedCadenceTeradata.user);

            query.put('scenario/'+$scope.loadedCadenceTeradata.id+'/', $scope.updateCadenceData, function (r) {
                if (r.status == 200 || r.status == 201) {
                    $rootScope.grayedOut=0;
                    console.log(r.data);
                    $scope.closePop();
                    
                }
            });

            //console.log($scope.loadedCadenceTeradata.cadence_planning_name);
        }
    }

    $scope.loadCadenceTeradata= function(index,viewCadenceResponse){
        $scope.nowAdding = false;
        $scope.ifNewErr = false;
         $scope.isLoad = false;
        $scope.data.folderData = "";
        $scope.loadedCadenceTeradata= viewCadenceResponse;
        console.log(viewCadenceResponse);
        $scope.loadCadenceTeradataData = {};
        $scope.loadCadenceTeradataData.combination_key = viewCadenceResponse['combination_key'];
        $scope.loadCadenceTeradataData.season = viewCadenceResponse['season'];
        $scope.loadCadenceTeradataData.brand_name = viewCadenceResponse['Brand_name'];
        $scope.loadCadenceTeradataData.season_key = viewCadenceResponse['season_Key'];
        $scope.loadCadenceTeradataData.year_key = viewCadenceResponse['Year_Key'];
        $scope.teradataRequest($scope.loadCadenceTeradataData);
        /*document.getElementById('selectedId'+index).className = "ng-scope";
        $scope.selectedRow = null;*/
        $scope.closePop();

    }


    /*$scope.createObj=function(teradataResponse,index){
        
        teradataProductObject={}
        teradataResponse.response[index]['week_revenue'] = teradataResponse['week_revenue'];
        teradataProductObject=teradataResponse;
        teradataProductObject.msrp = teradataResponse['msrp'];
        teradataObject.week_inv = teradataResponse['week_inv'];
        teradataObject.week_revenue = teradataResponse['week_revenue'];
        teradataObject.frequency = teradataResponse['frequency'];
        teradataObject.top_opportunity_flag = teradataResponse['top_opportunity_flag'];
        teradataProductObject.logo = "img/Shoe1.png";
        if(teradataResponse['brand_name'] == 'BRAND 1'){
          teradataProductObject.isPink= true;
        }
        else if(teradataResponse['brand_name'] == 'BRAND 2'){
            teradataProductObject.isBlue= true;
        }else{
            teradataProductObject.isGrey= true;
        }
        //return teradataProductObject;
        brandObject ={}
        brandObject.brand = teradataResponse.response[i]['brand_name'];
        teradataObject.brand_name.push(brandObject);
        teradataObject.product.push(teradataProductObject);
    }*/

    
    /*$scope.getBetweenDayTeradata= function(startDate,endDate,teradataResponse) {
        //console.log(teradataResponse.response);    
        var start_date = new Date(startDate),
               end_date= new Date(endDate),
               fridays = [];
               
        //var mid_date =angular.copy(start_date);
        while (start_date.getDay() !== 6) {
           start_date.setDate(start_date.getDate() + 1);
        }
        var j=0;
        while (start_date < end_date) {
            j=j+1;
            var col = 'col'+j;
            teradataObject={};
            teradataObject.product=[];
            teradataObject.brand_name=[];
            

            teradataObject.date=new Date(start_date.getTime());
            var mid_date = angular.copy(teradataObject.date);
            var mid_date_seven = new Date(mid_date.setDate(mid_date.getDate()-7)) ;
            for (var i=0; i < teradataResponse.response.length; i++) {
                plannedLaunchDate=new Date(teradataResponse.response[i]['planned_launch_date']);
                opportunityLaunchDate=new Date(teradataResponse.response[i]['launch_date']);

                //console.log(teradataResponse.response[i]['launch_flag']);

                var combination_value=$rootScope.combination_key.charAt(teradataResponse.response[i]['top_opportunity_flag']-1);
                
 
                if(typeof teradataResponse.response[i]['launch_flag'] != 'undefined'){ //alert(teradataResponse.response[i]['launch_flag']);
                    if(teradataResponse.response[i]['launch_flag']=='opportunity'){

                            if(opportunityLaunchDate <= start_date && opportunityLaunchDate > mid_date_seven){
                        
                                teradataProductObject={}
                                teradataResponse.response[i]['week_revenue'] = teradataResponse.response[i]['week_revenue'];
                                teradataProductObject=teradataResponse.response[i];
                                teradataProductObject.msrp = teradataResponse.response[i]['msrp'];
                                teradataObject.week_inv = teradataResponse.response[i]['week_inv'];
                                teradataObject.week_revenue = teradataResponse.response[i]['week_revenue'];
                                teradataObject.frequency = teradataResponse.response[i]['frequency'];
                                teradataObject.top_opportunity_flag = teradataResponse.response[i]['top_opportunity_flag'];
                                teradataProductObject.isPink = true;
                                teradataProductObject.ifStar = true;
                                teradataProductObject.logo = "img/Shoe1.png";


                                if(teradataResponse.response[i]['brand_name'] == 'BRAND 1'){
                                  teradataProductObject.isPink= true;
                                }
                                else if(teradataResponse.response[i]['brand_name'] == 'BRAND 2'){
                                    teradataProductObject.isBlue= true;
                                }else{
                                    teradataProductObject.isGrey= true;
                                }
                                
                                brandObject ={}
                                brandObject.brand = teradataResponse.response[i]['brand_name'];



                                teradataObject.brand_name.push(brandObject);
                                teradataObject.product.push(teradataProductObject);
                            }

                    }else{

                        if(plannedLaunchDate <= start_date && plannedLaunchDate > mid_date_seven){


                            teradataProductObject={}
                            teradataResponse.response[i]['week_revenue'] = teradataResponse.response[i]['week_revenue'];
                            teradataProductObject=teradataResponse.response[i];
                            teradataProductObject.msrp = teradataResponse.response[i]['msrp'];
                            teradataObject.week_inv = teradataResponse.response[i]['week_inv'];
                            teradataObject.week_revenue = teradataResponse.response[i]['week_revenue'];
                            teradataObject.frequency = teradataResponse.response[i]['frequency'];
                            teradataObject.top_opportunity_flag = teradataResponse.response[i]['top_opportunity_flag'];
                            teradataProductObject.isPink = true;
                            teradataProductObject.ifStar = true;
                            teradataProductObject.logo = "img/Shoe1.png";
                            if(teradataResponse.response[i]['brand_name'] == 'BRAND 1'){
                              teradataProductObject.isPink= true;
                            }
                            else if(teradataResponse.response[i]['brand_name'] == 'BRAND 2'){
                                teradataProductObject.isBlue= true;
                            }else{
                                teradataProductObject.isGrey= true;
                            }
                            //$rootScope.combination_key =  teradataResponse.response[i]['combination_key'];

                            brandObject ={}
                            brandObject.brand = teradataResponse.response[i]['brand_name'];



                            
                            teradataObject.brand_name.push(brandObject);
                            teradataObject.product.push(teradataProductObject);
                        }

                    }
                }else{//alert(' not present');
                    if(teradataResponse.response[i]['top_opportunity_flag'] == '0' ){
                        if(plannedLaunchDate <= start_date && plannedLaunchDate > mid_date_seven){


                            teradataProductObject={}
                            teradataResponse.response[i]['week_revenue'] = teradataResponse.response[i]['week_revenue'];
                            teradataProductObject=teradataResponse.response[i];
                            teradataProductObject.msrp = teradataResponse.response[i]['msrp'];
                            teradataObject.week_inv = teradataResponse.response[i]['week_inv'];
                            teradataObject.week_revenue = teradataResponse.response[i]['week_revenue'];
                            teradataObject.frequency = teradataResponse.response[i]['frequency'];
                            teradataObject.top_opportunity_flag = teradataResponse.response[i]['top_opportunity_flag'];
                            teradataProductObject.isPink = true;
                            teradataProductObject.ifStar = true;
                            teradataProductObject.logo = "img/Shoe1.png";
                            if(teradataResponse.response[i]['brand_name'] == 'BRAND 1'){
                              teradataProductObject.isPink= true;
                            }
                            else if(teradataResponse.response[i]['brand_name'] == 'BRAND 2'){
                                teradataProductObject.isBlue= true;
                            }else{
                                teradataProductObject.isGrey= true;
                            }
                            //$rootScope.combination_key =  teradataResponse.response[i]['combination_key'];

                            brandObject ={}
                            brandObject.brand = teradataResponse.response[i]['brand_name'];



                            
                            teradataObject.brand_name.push(brandObject);
                            teradataObject.product.push(teradataProductObject);
                        }

                    }
                    else if (combination_value == 1 &&  teradataResponse.response[i]['top_opportunity_flag'] != '0'){
                        if(opportunityLaunchDate <= start_date && opportunityLaunchDate > mid_date_seven){
                            teradataProductObject={}
                            teradataResponse.response[i]['week_revenue'] = teradataResponse.response[i]['week_revenue'];
                            teradataProductObject=teradataResponse.response[i];
                            teradataProductObject.msrp = teradataResponse.response[i]['msrp'];
                            teradataObject.week_inv = teradataResponse.response[i]['week_inv'];
                            teradataObject.week_revenue = teradataResponse.response[i]['week_revenue'];
                            teradataObject.frequency = teradataResponse.response[i]['frequency'];
                            teradataObject.top_opportunity_flag = teradataResponse.response[i]['top_opportunity_flag'];
                            teradataProductObject.isPink = true;
                            teradataProductObject.ifStar = true;
                            teradataProductObject.logo = "img/Shoe1.png";
                            if(teradataResponse.response[i]['brand_name'] == 'BRAND 1'){
                              teradataProductObject.isPink= true;
                            }
                            else if(teradataResponse.response[i]['brand_name'] == 'BRAND 2'){
                                teradataProductObject.isBlue= true;
                            }else{
                                teradataProductObject.isGrey= true;
                            }
                            //$rootScope.combination_key =  teradataResponse.response[i]['combination_key'];

                            brandObject ={}
                            brandObject.brand = teradataResponse.response[i]['brand_name'];



                            teradataObject.brand_name.push(brandObject);
                            teradataObject.product.push(teradataProductObject);
                        }

                    }else{
                        if(plannedLaunchDate <= start_date && plannedLaunchDate > mid_date_seven){
                            
                            teradataProductObject={}
                            teradataResponse.response[i]['week_revenue'] = teradataResponse.response[i]['week_revenue'];
                            teradataProductObject=teradataResponse.response[i];
                            teradataProductObject.msrp = teradataResponse.response[i]['msrp'];
                            teradataObject.week_inv = teradataResponse.response[i]['week_inv'];
                            teradataObject.week_revenue = teradataResponse.response[i]['week_revenue'];
                            teradataObject.frequency = teradataResponse.response[i]['frequency'];
                            teradataObject.top_opportunity_flag = teradataResponse.response[i]['top_opportunity_flag'];
                            
                            teradataProductObject.logo = "img/Shoe1.png";
                            if(teradataResponse.response[i]['brand_name'] == 'BRAND 1'){
                              teradataProductObject.isPink= true;
                            }
                            else if(teradataResponse.response[i]['brand_name'] == 'BRAND 2'){
                                teradataProductObject.isBlue= true;
                            }else{
                                teradataProductObject.isGrey= true;
                            }
                            //$rootScope.combination_key =  teradataResponse.response[i]['combination_key'];

                            brandObject ={}
                            brandObject.brand = teradataResponse.response[i]['brand_name'];


                            teradataObject.brand_name.push(brandObject);
                            teradataObject.product.push(teradataProductObject);
                        }
                    }
                }
                
            }
            fridays.push(teradataObject);
            start_date.setDate(start_date.getDate() + 7);
            
        }
        console.log(fridays);
        return fridays;
    }*/

    
    $scope.modifyPlannedOpportinity=function(obj, launch_type){ 
        console.log(obj);
        console.log($scope.dashboardGraphProduct);

        var dashboardResponse=JSON.parse(localStorage.dashboardResponse);
        var launch_date=obj.launch_date;
        var oppo_launch_date=obj.launch_date;
        var name=obj.style_name;
        fullResposeObj={};
        var responseArr=[];
        /*console.log('dssd');
        console.log($scope.dashboardResponse);
        console.log('dssd1');*/
        for(var i = 0 ; i < dashboardResponse.response.length; i++)
        {      
            responseObj={};  

            if(dashboardResponse.response[i].launch_flag){ 
                if(dashboardResponse.response[i].style_name==name && dashboardResponse.response[i].launch_date==obj.launch_date ){
                    dashboardResponse.response[i].launch_flag=launch_type;
                    dashboardResponse.response[i].combination_key=$rootScope.combination_key;
                    dashboardResponse.response[i]=dashboardResponse.response[i];
                }else{
                    dashboardResponse.response[i].launch_flag=dashboardResponse.response[i].launch_flag;
                    dashboardResponse.response[i]=dashboardResponse.response[i];
                }  
            }else{
                if(dashboardResponse.response[i].style_name==name && dashboardResponse.response[i].launch_date==obj.launch_date ){
                    dashboardResponse.response[i].launch_flag=launch_type;
                    dashboardResponse.response[i].combination_key=$rootScope.combination_key;
                    dashboardResponse.response[i]=dashboardResponse.response[i];
                }else{
                    //dashboardResponse.response[i].launch_flag='planned';
                    dashboardResponse.response[i]=dashboardResponse.response[i];
                }
                
            } 
             
            responseArr.push(dashboardResponse.response[i]);       
        }
        fullResposeObj.response = responseArr;
        localStorage.setItem("dashboardResponse", JSON.stringify(fullResposeObj));
        $scope.dashboardGraphProduct = $scope.getBetweenDayTeradata('2016-12-30','2017-04-01',fullResposeObj);

    }

    $scope.closePop = function() {

        $scope.showFiles = false;
        $scope.fnIconClick = false;;
        $scope.showFullLay = false;
        $scope.scenarioerror=false;

    }

    $scope.closePop1 = function(index) {
        document.getElementById('selectedId'+index).className = "ng-scope";
        $scope.selectedRow = null;
        $scope.showFiles = false;
        $scope.fnIconClick = false;;
        $scope.showFullLay = false;
        $scope.scenarioerror=false;

    }

    $scope.checkinarray=function(obj, sel_brand, type){
        /*console.log(type);
        console.log(sel_brand);
        console.log(obj);*/
        var isPresentArr=[];
        for (var i=0; i < obj.brand_name.length; i++) {
            if(obj.brand_name[i].brand==sel_brand || sel_brand=='All'){
                isPresentArr.push('true');
            }else{
                isPresentArr.push('false');
            }
        }
        if(isPresentArr.indexOf('true')==-1){
            return false;
        }else{
            return true;
        }
    }


    $('#slideout1').hide();
 
    $('#print_dom2').hide();
    $('#exportpage3').hide();

    
    $('.planHeader').hide();
    

    $scope.downloadPdf=function(){
        $('#slideout1').removeAttr('style');
        $('#slideout1').show();
        $('.planHeader').show();
        //$('#exportpage3').show();
        console.log("working...");

        var printDom1 = $("#printShow")[0];


        var doc = new jsPDF('landscape','mm',[490,297]);


        doc.addHTML(printDom1,55,0.5,{pagesplit: true}, function() {
            //doc.addPage();
            doc.addPage([200, 200], 'portrait');

            doc.addHTML($('#slideout1')[0],0,0, function() {
                doc.save('CadencePlan.pdf');
                        $('#slideout1').hide();
                        $('.planHeader').hide();
            });     
        });



        /*query.get('scenario/hellopdf/',  function (r) {
            console.log(r)

        });*/
    var exportThirdArray = angular.copy($scope.seasonDateArray);
 
        
        if($scope.dashboardResponse.category_selected=="All"){
                angular.forEach(exportThirdArray['current_season'],function(value,key){
                    $scope.finalArr = []
                    angular.forEach(value['product'],function(value1,key1){
                         if(value1['style_abbr'] =='?'){
                            value1['style_abbr'] = '';
                        }
                        
                        value1['defaultvalue']['planned_inv'] = $scope.roundValue(parseFloat(value1['defaultvalue']['planned_inv']));
                        value1['defaultvalue']['week1_str'] = $scope.percentageCalulation(parseFloat(value1['defaultvalue']['week1_str']));
                        value1['defaultvalue']['prcnt_avg_mrkp'] = $scope.percentageCalulation(parseFloat(value1['defaultvalue']['prcnt_avg_mrkp']));
                        value1['total_inventory'] = $scope.roundValue(parseFloat(value1['total_inventory']));
                        value1['week1_str'] = $scope.percentageCalulation(parseFloat(value1['week1_str']));
                        value1['prcnt_avg_mrkp'] = $scope.percentageCalulation(value1['prcnt_avg_mrkp']);
                        /*value1['total_inventory'] = $scope.roundValue(value1['total_inventory']);
                        //value1['week1_str'] = $scope.roundValue(value1['week1_str']);
                        if(value1['top_opportunity_flag'] != 0){
                            value1['last_prcnt_avg_mrkp'] = $scope.percentageCalulation(value1['defaultvalue']['prcnt_avg_mrkp']);
                        }
                        if(value1['top_opportunity_flag'] == 0){
                            value1['last_prcnt_avg_mrkp'] = $scope.percentageCalulation(value1['prcnt_avg_mrkp']);
                        
                        }*/
                            $scope.finalArr.push(value1);

                    });
                    value['product'] = $scope.finalArr;
                });
        }else{
            angular.forEach(exportThirdArray['current_season'],function(value,key){
                            $scope.finalArr = []
                angular.forEach(value['product'],function(value1,key1){
                    if($scope.dashboardResponse.category_selected == value1['brand_name']){
                         if(value1['style_abbr'] =='?'){
                        value1['style_abbr'] = '';
                    }
                    value1['defaultvalue']['planned_inv'] = $scope.roundValue(parseFloat(value1['defaultvalue']['planned_inv']));
                    value1['defaultvalue']['week1_str'] = $scope.percentageCalulation(parseFloat(value1['defaultvalue']['week1_str']));
                    value1['defaultvalue']['prcnt_avg_mrkp'] = $scope.percentageCalulation(parseFloat(value1['defaultvalue']['prcnt_avg_mrkp']));
                    value1['total_inventory'] = $scope.roundValue(parseFloat(value1['total_inventory']));
                    value1['week1_str'] = $scope.percentageCalulation(parseFloat(value1['week1_str']));
                    value1['prcnt_avg_mrkp'] = $scope.percentageCalulation(value1['prcnt_avg_mrkp']);
                    //value1['week1_str'] = $scope.roundValue(value1['week1_str']);
                    /*if(value1['top_opportunity_flag'] != 0){
                        value1['last_prcnt_avg_mrkp'] = $scope.percentageCalulation(value1['defaultvalue']['prcnt_avg_mrkp']);
                    }
                    if(value1['top_opportunity_flag'] == 0){
                        value1['last_prcnt_avg_mrkp'] = $scope.percentageCalulation(value1['prcnt_avg_mrkp']);
                    
                    }*/
                        $scope.finalArr.push(value1);

                    }
                });
                value['product'] =$scope.finalArr;
            });
                    
        }
        console.log(exportThirdArray);
        
        query.post('scenario/hellopdf/', exportThirdArray,function (r) {
            
            var file = new Blob([r.data], {type: 'application/pdf'});
	    //saveAs(file,'Detailed Plan.pdf');
            var fileURL = URL.createObjectURL(file);
            var newWin = $window.open(fileURL);
            if(!newWin || newWin.closed || typeof newWin.closed=='undefined') { 
                alert('Please Ensure pop Blockers are disabled for exporting Detailed Plan');
            }
            
        });
       

        
    }



    $scope.clearCadence=function(){
        $rootScope.combination_key == localStorage.combination_key
        $rootScope.grayedOut=0;
        /*angular.forEach($scope.dashboardGraphProduct,function(value,key){
            angular.forEach(value['product'],function(value1,key1){
                value1['combination_key'] = localStorage.combination_key;
            });
        });*/
        $scope.data = {};
        $scope.data.combination_key = "0";
        $scope.data.season = $scope.dashboardResponse.season_selected;
        $scope.data.brand_name = $scope.dashboardResponse.category_selected;
        $scope.data.year_key = '17';
        $scope.data.season_key = 'SP';
        $scope.loadedCadenceTeradata = undefined;
        $scope.teradataRequest($scope.data);
        
    }
    $scope.categorySelected ='';
    $scope.showFile = function(plannigFiles){
        $scope.showFiles = true;
        $scope.data.folderData = "";
        $scope.nowAdding = false;
        $scope.planningBrand_id = plannigFiles.id;
        $scope.plannigFiles = plannigFiles.related_plannings;
        console.log( $scope.plannigFiles);
        //$scope.categorySelected = brand_name;

    }

    $scope.back = function(){
        $scope.showFiles = false;
        $scope.ifNewErr = false;
        $scope.scenarioerror=false;
        //document.getElementById('selectedId'+index).className = "ng-scope";
        $scope.selectedRow = null;

    }



    $scope.data = [
        { letter: "151K", frequency: .08167 },
        { letter: "121K", frequency: .01492 },
        { letter: "30K", frequency: .02780 },
        { letter: "52K", frequency: .04253 },
        { letter: "71K", frequency: .12702 },
        { letter: "56K", frequency: .02288 },
        { letter: "32K", frequency: .02022 },
        { letter: "45K", frequency: .06094 },
        { letter: "43K", frequency: .06973 },
        { letter: "76K", frequency: .00153 },
        { letter: "48K", frequency: .00747 },
        { letter: "90K", frequency: .04025 },
        { letter: "92K", frequency: .02517 }
    ];


    $scope.products = [{
            "col1": [{
                "name": "AJ14",
                "logo": "img/Shoe1.png",
                "isPink": true,
                "ifStar": true
            }, {
                "name": "Kobe X",
                "logo": "img/Shoe2.png",
                "isBlue": true
            }, {
                "name": "KD 8",
                "logo": "img/Shoe3.jpg",
                "isBlue": true,
                "ifStar": true
            }]
        }, {
            "col1": [{
                "name": "AJ 1",
                "logo": "img/Shoe4.jpg",
                "isPink": true,
                "ifStar": false
            }, {
                "name": "AJ 1",
                "logo": "img/Shoe5.jpg",
                "isPink": true,
                "ifStar": true
            }, {
                "name": "Lebron XII",
                "logo": "img/Shoe6.jpg",
                "isBlue": true,
                "ifStar": true
            }, {
                "name": "Air F",
                "logo": "img/Shoe7.jpg",
                "isGrey": true,
                "ifStar": false
            }]
        }, {
            "col1": [{
                "name": "AJ 8",
                "logo": "img/Shoe8.jpg",
                "isPink": true,
                "ifStar": true
            }, {
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }]
        }, {
            "col1": [{
                "name": "AJ 1",
                "logo": "img/Shoe10.jpg",
                "isPink": true,
                "ifStar": false
            }, {
                "name": "AJ Spike",
                "logo": "img/Shoe11.jpg",
                "isPink": true,
                "ifStar": true
            }, {
                "name": "Kobe X",
                "logo": "img/Shoe12.jpg",
                "isGrey": true,
                "ifStar": true
            }]
        }, {
            "col5": [{
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }, {
                "name": "AJ Spike",
                "logo": "img/Shoe11.jpg",
                "isPink": true,
                "ifStar": true
            }, {
                "name": "Air F",
                "logo": "img/Shoe7.jpg",
                "isGrey": true,
                "ifStar": false
            }, ]
        }, {
            "col6": [{
                "name": "Lebron XII",
                "logo": "img/Shoe6.jpg",
                "isBlue": true,
                "ifStar": true
            }, {
                "name": "AJ 1",
                "logo": "img/Shoe10.jpg",
                "isPink": true,
                "ifStar": false
            }, {
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }, {
                "name": "Air F",
                "logo": "img/Shoe7.jpg",
                "isGrey": true,
                "ifStar": false
            }, {
                "name": "KD 8",
                "logo": "img/Shoe3.jpg",
                "isBlue": true,
                "ifStar": true
            }]
        }, {
            "col7": [{
                "name": "AJ 1",
                "logo": "img/Shoe10.jpg",
                "isPink": true,
                "ifStar": false
            }]
        }, {
            "col8": [{
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }, {
                "name": "Lebron XII",
                "logo": "img/Shoe6.jpg",
                "isBlue": true,
                "ifStar": true
            }]
        }, {
            "col9": [{
                "name": "KD 8",
                "logo": "img/Shoe3.jpg",
                "isBlue": true,
                "ifStar": true
            }, {
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }]
        }, {
            "col10": [{
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }]
        }, {
            "col11": [{
                "name": "Blazer Mid",
                "logo": "img/Shoe9.jpg",
                "isGrey": true,
                "ifStar": false
            }, {
                "name": "AJ 1",
                "logo": "img/Shoe10.jpg",
                "isPink": true,
                "ifStar": false
            }, {

                "name": "Kobe X",
                "logo": "img/Shoe12.jpg",
                "isGrey": true,
                "ifStar": true
            }, {
                "name": "Lebron XII",
                "logo": "img/Shoe6.jpg",
                "isBlue": true,
                "ifStar": true
            }, {
                "name": "AJ Spike",
                "logo": "img/Shoe11.jpg",
                "isPink": true,
                "ifStar": true
            }]
        }, {
            "col12": [{

                "name": "Lebron XII",
                "logo": "img/Shoe6.jpg",
                "isBlue": true,
                "ifStar": true
            }]
        }, {
            "col13": [{
                "name": "Lebron XII",
                "logo": "img/Shoe6.jpg",
                "isBlue": true,
                "ifStar": true
            }, {
                "name": "Kobe X",
                "logo": "img/Shoe12.jpg",
                "isGrey": true,
                "ifStar": true
            }]
        }

    ];

 

}]);
angular.module('nikeApp').controller("sliderController", ['$scope', function sliderController($scope) {
    $scope.items = [{
        "name": "Apples",
        "time": 30
    }, {
        "name": "Oranges",
        "time": 45
    }, {
        "name": "Grapes",
        "time": 30
    }, {
        "name": "Bananas",
        "time": 15
    }, {
        "name": "Kiwi",
        "time": 5
    }, {
        "name": "Watermelon",
        "time": 15
    }, {
        "name": "Pear",
        "time": 10
    }, {
        "name": "Avocado",
        "time": 45
    }, {
        "name": "Mango",
        "time": 10
    }, {
        "name": "Papaya",
        "time": 15
    }, ]

    $scope.rangeOpts = [5, 10, 15, 30, 45];
    $scope.rangeNum = 10;

    $scope.prepTimeFilter = function(location) {
        return location.time <= $scope.rangeNum;
    };

}]);
